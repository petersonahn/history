package string;

public class String_02 {

	public static void main(String[] args) {
		
		String str1 = "Hello ";
		String str2 = "Java";
		
		System.out.println("str1 주소 >>> " + System.identityHashCode(str1));
		
		System.out.println("str2 주소 >>> " + System.identityHashCode(str2));
		
		System.out.println();
		
		// 문자열 결합
		
		str1 = str1 + str2; // str1 += str2;
		
		System.out.println(str1);
		
		System.out.println("str1 주소 >>> " + System.identityHashCode(str1));
		
		/*
		 * - 생성된 String 객체는 수정이 불가능함.
		 * - 문자열이 결합이 된 경우에는 새로운 주소에 문자열이 만들어짐.
		 * - 하지만 결합 전에 만들었던 문자열 객체는 여전히 존재함.
		 */
	}

}
