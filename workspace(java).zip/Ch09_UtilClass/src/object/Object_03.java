package object;

public class Object_03 {

	public static void main(String[] args) {
		String[] str = new String[4];
		
		str[0] = "홍길동";
		str[1] = "hong";
		str[2] = "경기도 고양시";
		str[3] = "010-1111-1234";
		
	    for(String s : str) {
	    	System.out.println("str 배열 요소 >>> " + s);
	    }
	    
	    System.out.println();
	    
	    Object[] obj = new Object[4];
	    
	    obj[0] = "세종대왕";
	    obj[1] = 135;
	    obj[2] = true;
	    obj[3] = 3.4567;
	    
	    for(Object o : obj) {
	    	System.out.println("object 배열 요소 >>> " + o);
	    }
	}

}
