package object;

/*
 * toString() 메서드 재정의
 * - Object 클래스에서 상속을 받은 메서드를 유용한 정보가
 *   반환이 되도록 재정의 하는 것을 말함.
 * - 해당 클래스의 멤버변수가 정보를 가지고 있는데 가지고 있는
 *   정보에 올바른 값이 담겨있는지, 혹은 틀린 정보가 담겨있는지
 *   확인을 하고 싶은 경우에 toString() 메서드를 재정의하여
 *   값을 확인할 수 있음.
 */

public class Student {

	String hakbun;
	String name;
	String major;
	String phone;
	String addr;
	
	public Student() {
		
	}
	
    public Student(String hakbun, String name, String major, String phone, String addr) {
		this.hakbun = hakbun;
		this.name = name;
		this.major = major;
		this.phone = phone;
		this.addr = addr;
	}
    
    void getStudentInfo() {
    	System.out.println("학생 학번 >>> " + hakbun);
    	System.out.println("학생 이름 >>> " + name);
    	System.out.println("학생 학과 >>> " + major);
    	System.out.println("학생 연락처 >>> " + phone);
    	System.out.println("학생 주소 >>> " + addr);
    }
}
