package exam;

public class Rectangle {
	int width;
	int heigth;
	
	public Rectangle() {
		
	}
	
    public Rectangle(int w, int h) {
		width = w;
		heigth = h;
	}
    
    void extent(){
    	System.out.println("사각형의 넓이 : " + (width*heigth));
    }
    
    void round(){
    	System.out.println("사각형의 둘레 : " + (2*(width+heigth)));
    }
}
