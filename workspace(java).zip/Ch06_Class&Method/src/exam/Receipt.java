package exam;


public class Receipt {
	
	String name;
	int dan;
	int su;
	
	public Receipt() {	}
	public Receipt(String n, int d, int s) {	
		this.name = n;
		this.dan = d;
		this.su = s;
	}
	
	
	
}
