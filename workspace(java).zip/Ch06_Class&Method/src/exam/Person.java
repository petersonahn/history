package exam;

public class Person {
	
	
	String name;
	String gender;
	int age;
	
	public Person() { }
	
	public Person(String n, String g, int a) { 


		this.name = n;
	    this.gender = g;
		this.age = a;
		
	}
	
	void getPersonInfo() {
		
		
		
		System.out.println("=======================");
		System.out.println("이름 : " + name);
		if(gender.equals("male")) {
			System.out.println("성별 : 남자" );
		} else if(gender.equals("female")) {
			System.out.println("성별 : 여자" );
		}
		System.out.println("나이 : " + age + "세");
		
	}  // getMemberInfo() 메서드 end
}
