package exam;

import java.util.Scanner;

public class Exam_06_01 {
	
	public static final double TAX_RATE = 1.1;
	

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("메뉴는 몇개인가요? : ");
		Receipt[] receipts = new Receipt[sc.nextInt()];
		
		for(int i=0; i<receipts.length; i++) {
			System.out.println((i+1) + " 번째 메뉴의 이름, 단가, 수량을 입력하세요.....");
			
			receipts[i] = new Receipt(sc.next(), sc.nextInt(), sc.nextInt());
			
		}
		System.out.println();
		
		int totalPrice = 0;       // 총금액(청구금액) 변수

		System.out.println("----------------------------------------");
		System.out.println("품명\t 단가\t 수량\t 금액\t");
		System.out.println("----------------------------------------");
		
		for(int i=0; i<receipts.length; i++) {
			System.out.printf("%s\t %,d\t %,d\t %,d원\n", 
					receipts[i].name, receipts[i].dan, receipts[i].su,
					(receipts[i].dan * receipts[i].su));
			
			
			totalPrice += (receipts[i].dan * receipts[i].su);
		}
		
		int supplyPrice = (int) (totalPrice / Exam_06_01.TAX_RATE);
		
		int vat = totalPrice - supplyPrice;
		
		System.out.println("----------------------------------------");
		System.out.printf("공급가액\t\t\t%,d원\n", supplyPrice);
		System.out.printf("부가세액\t\t\t%,d원\n", vat);
		System.out.println("----------------------------------------");
		System.out.printf("청구금액\t\t\t%,d원\n", totalPrice);
				
		sc.close();
	}

}
