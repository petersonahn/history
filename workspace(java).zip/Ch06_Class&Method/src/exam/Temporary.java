package exam;

public class Temporary {
	String name;
	int time;
	int pay;
	
	public Temporary() {}
	
	public Temporary(String n, int t, int p) {
		this.name = n;
		this.time = t;
		this.pay = p;
		
	}
	
	void getTemporaryInfo() {
		int sum = time * pay;
		int gong = (int) (sum * 0.03);
		int total = sum - gong;
		
		System.out.println("=============================");
		System.out.println("이름 : " + name);
		System.out.println("총급여 : " + sum + "원");
		System.out.println("공제액 : " + gong + "원");
		System.out.println("실지급액 : " + total + "원");
	}
}
