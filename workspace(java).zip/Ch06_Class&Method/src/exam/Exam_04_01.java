package exam;

import java.util.Scanner;

public class Exam_04_01 {
	
	// 1번 메뉴 - 학생 정보 입력
	public static void input(String[] n, int[] h, String[] m, String[] p, Scanner sc) {
				
		
		System.out.println("n >>> " + n);
        System.out.println("h >>> " + h);
        System.out.println("m >>> " + m);
        System.out.println("p >>> " + p);
		
		for(int i = 0; i < n.length; i++) {
			
			System.out.println("<<< " + (i+1) + " 번째 학생 정보 입력 >>>");
			System.out.print("이름 입력 : ");
			n[i] = sc.next();
			System.out.print("학번 입력 : ");
			h[i] = sc.nextInt();
			System.out.print("학과 입력 : ");
			m[i] = sc.next();
			System.out.print("전화번호 입력 : ");
			p[i] = sc.next();
			
			System.out.println();
		}
	}  // input 메서드 end
	
	// 2번 메뉴 - 학생 정보 출력
	public static void output(String[] n, int[] h, String[] m, String[] p) {
	
		for(int i=0; i < n.length; i++) {
			System.out.println("*** " + (i+1) + " 번째 학생 정보 ***");
			System.out.print("이 름 : " + n[i] + "\t");
			System.out.print("학 번 : " + h[i] + "\t");
			System.out.print("학 과 : " + m[i] + "\t");
			System.out.print("연락처 : " + p[i] + "\t");
			System.out.println(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
		}
	
	} // output 메서드 end
	// 3번 메뉴 - 학생조회
	public static void search(String[] n, int[] h, String[] m, String[] p, Scanner sc) {
		
		System.out.print("조회할 학생의 학번을 입력하세요. : ");
		
		int hakbun = sc.nextInt();
		
		for(int i=0; i<h.length; i++) {
			if(hakbun == h[i]) {
				System.out.println("이 름 : " + n[i]);
				System.out.println("학 번 : " + h[i]);
				System.out.println("학 과 : " + m[i]);
				System.out.println("연락처 : " + p[i]);
			}
		}
		
	} // search 메서드 end
	
	
	
	// 4번 메뉴 - 정보수정
	
	public static void modify(int[] h, String[] m, String[] p, Scanner sc) {
        
		System.out.print("수정할 학생의 학번을 입력하세요. : ");
		
		int hakbun = sc.nextInt();
		
		for(int i=0; i < m.length; i++) {
			if(hakbun == h[i]) {
				System.out.print("수정할 학생의 학과 입력 : ");
				m[i] = sc.next();
				System.out.print("수정할 학생의 연락처 입력 : ");
				p[i] = sc.next();
			}
		}
		
	} // modify 메서드 end
	
	
    // 5번 메뉴 - 프로그램 종료
	public static String end(Scanner sc) {		
		
	    System.out.print("프로그램을 종료하시겠습니까?(Y:종료 / N:계속) : ");
		return sc.next();
		
		
	} // end 메서드 end
	
	public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
		
        System.out.print("학생 수를 입력하세요 : ");
		
        
        String[] names = new String[sc.nextInt()]; // 이름 배열
        
        int[] stunum = new int[names.length];         
        String[] dep = new String[stunum.length];           
        String[] phone = new String[dep.length];  
        
        System.out.println("names >>> " + names);
        System.out.println("stunum >>> " + stunum);
        System.out.println("dep >>> " + dep);
        System.out.println("phone >>> " + phone);
        
        
        while(true) {
        	System.out.println("1. 학생 등록");
        	System.out.println("2. 전체 출력");
        	System.out.println("3. 학생 조회");
        	System.out.println("4. 정보 수정");
        	System.out.println("5. 프로그램 종료");
        	
        	System.out.println();
        	
        	System.out.println("학생 관리 메뉴 중 하나를 선택하세요. : ");
        	
        	String res = "";
        	
        	switch(sc.nextInt()) {
        	case 1 :  // 학생 등록 메뉴 선택
        		input(names, stunum, dep, phone, sc);
        		break;
        	case 2 :  // 전체 출력 메뉴 선택
        		output(names, stunum, dep, phone);
        		break;
        	case 3 :  // 학생 조회 메뉴 선택
        		search(names, stunum, dep, phone, sc);
        		break;
        	case 4 :  // 정보 수정 메뉴 선택
        		modify(stunum, dep, phone, sc);
        		break;
        	case 5 :  // 프로그램 종료 메뉴 선택
        		res = end(sc);
        		break;

        		
        	} 
        	
        	if(res.equalsIgnoreCase("Y")) {
    			break;
    		} else if(res.equalsIgnoreCase("N")) {
    			continue;
    		}
        	
        	
        	
        } // while 반복문 end
        System.out.println("프로그램이 종료되었습니다. 수고하셨습니다!");
        sc.close();
		
        
	}

}
