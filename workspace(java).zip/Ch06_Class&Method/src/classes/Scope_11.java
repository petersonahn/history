package classes;

public class Scope_11 {

	public static void main(String[] args) {

		Scope scope = new Scope();
		
		scope.output();
	}

}
