package classes;

public class Member {
	
	String id;
	String name;
	int age;
	String phone;
	String job;
	
	public Member(String i, String n, int a, 
			String p, String j) { 

		this.id = i;
		this.name = n;
		this.age = a;
		this.phone = p;
		this.job = j;
	}
	
	void getMemberInfo() {
		System.out.println("회원 아이디 >>> " + id);
		System.out.println("회원 이름 >>> " + name);
		System.out.println("회원 나이 >>> " + age);
		System.out.println("회원 연락처 >>> " + phone);
		System.out.println("회원 직업 >>> " + job);
		
	}  // getMemberInfo() 메서드 end
}
