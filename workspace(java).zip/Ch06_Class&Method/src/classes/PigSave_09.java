package classes;

public class PigSave_09 {

	public static void main(String[] args) {
		PigSave save = new PigSave(0);
		
		save.deposit(30000);
		save.deposit(40000);
		save.withdraw(40000);
		save.deposit(20000);
		save.withdraw(60000);
		
		// 이렇게 접근을 하면 안됨.
		// save.balance = 100000;
	}

}
