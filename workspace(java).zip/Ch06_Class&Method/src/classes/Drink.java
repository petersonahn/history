package classes;

// 음료 자판기

// 음료(6개) - 콜라, 사이다, 캔커피, 데자와, 솔의눈, 포카리스웨트

public class Drink {
	// 멤버변수
	String name;         // 음료 이름
	int price;           // 음료 가격
	
	public Drink() { }  // 기본 생성자
	
	public Drink(String name, int price) { 
		this.name = name;
		this.price = price;
	} // 인자 생성자
	
	
	
}
