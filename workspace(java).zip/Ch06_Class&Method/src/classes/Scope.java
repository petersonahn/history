package classes;

public class Scope {
	
	int su = 30;
	
	void output() {
		int su = 10;
		
		/*
		 * 메서드 안에서 전역변수와 이름이 같은 지역변수를
		 * 선언하고 난 후 해당변수를 출력을 하면 전역변수보다
		 * 지역변수의 우선 순위가 높음. 따라서 지역변수에
		 * 저장된 값이 출력이 됨.
		 */
		System.out.println("su >>> " + su);
		
		/*
		 * 만약 전역변수에 저장된 값을 출력하고 싶은 경우에는
		 * this라는 키워드를 변수명 앞에 붙인다.
		 */
		System.out.println("su >>> " + this.su);
	}
	
}
