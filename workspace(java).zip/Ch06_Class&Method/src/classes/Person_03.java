package classes;

public class Person_03 {

	public static void main(String[] args) {
		Person person = new Person();
		
		person.name = "홍길동";		
		person.age = 27;
		person.marriage = false;
		person.getPersonInfo();
		System.out.println();
		
        Person person1 = new Person();
		
		person1.name = "세종대왕";		
		person1.age = 50;
		person1.marriage = true;
		person1.getPersonInfo();
		System.out.println();
		
		
	}

}
