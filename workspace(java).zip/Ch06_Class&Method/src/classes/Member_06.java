package classes;

import java.util.Scanner;

/*
 * [문제] 회원 객체(Member)의 멤버를 구성하여 멤버에
 * 인자 생성자를 이용하여 키보드로 입력받은 초기값을
 * 할당 후 회원의 정보를 화면에 출력해보세요.
 * (회원 구성 요소 : 회원 아이디, 회원 이름, 회원 나이,
 *                회원 연락처, 회원 직업)
 */
public class Member_06 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("회원의 아이디, 이름, 나이, 연락처, 직업을 입력하세요.....");
		
		Member member = new Member
				(sc.next(), sc.next(), sc.nextInt(), sc.next(), sc.next());
		
		member.getMemberInfo();
		
		sc.close();
	}

}
