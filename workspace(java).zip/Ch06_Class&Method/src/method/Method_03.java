package method;

import java.util.Scanner;

/*
 *  매개변수가 있는 메서드 정의
 *  
 *    형식)
 *          [접근제한] 반환형 메서드 이름(type 변수1, type 변수2) {
 *               
 *               메서드 호출 시 실행 문장;
 *           
 *          }
 *          
 *  - 실인수와 가인수
 *    * 실인수 : 매개변수에 전달할 실제 값. ==> 메서드 호출 시에 사용됨.
 *    * 가인수 : 매개변수(가인수) ==> 메서드에 정의.
 *    * 실인수와 가인수는 반드시 type, 순서, 갯수가 일치해야 함. - 중요함.
 */

public class Method_03 {

	public static void add(int su) {
		
		int sum = 0;
		
		for(int i=1; i<=su; i++) {
			sum += i;
		}
		
		System.out.println("1 ~ " + su + "까지의 합 >>> " + sum);
		
	} // add() 메서드 end
	
public static void add(int start, int end) {
		
		int sum = 0;
		
		for(int i=start; i<=end; i++) {
			sum += i;
		}
		
		System.out.println(start + " ~ " + end + "까지의 합 >>> " + sum);
		
	} // add() 메서드 end
	
	public static void main(String[] args) {
		
		add(50);

		Scanner sc = new Scanner(System.in);
		
		System.out.print("합을 더할 시작 값 : ");
		
		int su1 = sc.nextInt();
		
        System.out.print("합을 더할 끝 값 : ");
		
		int su2 = sc.nextInt();
		
		
		add(su1, su2);
		
		sc.close();
	}

}
