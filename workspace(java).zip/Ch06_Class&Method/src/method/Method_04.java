package method;

import java.util.Scanner;

public class Method_04 {
	
	public static void plus(int a1, int a2) {
		System.out.println("덧셈 결과 >>> " + (a1 + a2));
	} // plus() 메서드 end 
	
	public static void minus(int a1, int a2) {
		System.out.println("뺄셈 결과 >>> " + (a1 - a2));
	} // minus() 메서드 end 
	
	public static void multiply(int a1, int a2) {
		System.out.println("곱셈 결과 >>> " + (a1 * a2));
	} // multiply() 메서드 end 
	
	public static void divide(int a1, int a2) {
		System.out.println("나눗셈(몫) 결과 >>> " + (a1 / a2));
	} // divide() 메서드 end 
	
	public static void mod(int a1, int a2) {
		System.out.println("나머지 결과 >>> " + (a1 % a2));
	} // mod() 메서드 end 
	

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("첫번째 정수 입력 : ");
		int su1 = sc.nextInt();
		
		System.out.print("두번째 정수 입력 : ");
		int su2 = sc.nextInt();
		
		System.out.print("연산자(+, -, *, /, %) 중 하나 입력 : ");
		char op = sc.next().charAt(0);
		
		// 연산자 변수에 입력된 연산기호를 가지고
		// 해당 기호에 맞는 메서드를 호출해 주자.
		
		switch(op) {
		case '+' :
			plus(su1, su2);
			break;
		case '-' :
			minus(su1, su2);
			break;
		case '*' :
			multiply(su1, su2);
			break;
		case '/' :
			divide(su1, su2);
			break;
		case '%' :
			mod(su1, su2);
			break;
		}
		sc.close();
	}

}
