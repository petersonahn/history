package method;

import java.util.Scanner;

// 개인별 성적 처리 - 무한반복

public class Method_09 {
    public static int total(int su1, int su2, int su3) {
		
		return su1 + su2 + su3;
	} // total() 메서드 end
	
    public static double average(int tot) {
		return tot / 3.0;
	} // average() 메서드 end
    
    public static String hakjum(double avg) {
		String grade = "";
		
		if(avg >= 90) {
			grade = "A학점";
		} else if(avg >= 80) {
			grade = "B학점";
		} else if(avg >= 70) {
			grade = "C학점";
		} else if(avg >= 60) {
			grade = "D학점";
		} else {
			grade = "F학점";
		}
		
		return grade;
	} // grade() 메서드 end

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while(true) {     // 무한 반복
			System.out.print("학생의 이름 입력 : ");
			
			String name = sc.next();
			
	        System.out.print("국어 점수 입력 : ");
			
			int kor = sc.nextInt();
			
	        System.out.print("영어 점수 입력 : ");
			
			int eng = sc.nextInt();
			
	        System.out.print("수학 점수 입력 : ");
			
			int mat = sc.nextInt();
			
			System.out.println();
			
			int sum = total(kor, eng, mat);
			
			double avg = average(sum);
			
			String grade = hakjum(avg);
			
			System.out.println("이   름 : " + name);
			System.out.println("국어점수 : " + kor + "점");
			System.out.println("영어점수 : " + eng + "점");
			System.out.println("수학점수 : " + mat + "점");
			System.out.println("총   점 : " + sum + "점");
			System.out.printf("평   균 : %.2f점\n", avg );
			System.out.println("학   점 : " + grade);
			System.out.println("::::::::::::::::::::::::::::::::::::::::::::");
			System.out.println();
			
			// 계속 진행할지, 종료를 할지 여부를 체크해야 함.
			System.out.print("계속 진행할까요?(Y:계속 / N:종료) : ");
			String res = sc.next();
			
			if(res.equalsIgnoreCase("N")) {
				break;
			} else if(res.equalsIgnoreCase("Y")) {
				continue;
			}
			System.out.println("수고 많이 하셨습니다~~~");
			sc.close();
		}
						
	}

}
