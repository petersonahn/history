package method;

/*
 * [문제] 1 ~ 100 까지의 홀수의 합과 짝수의 합을 구하는 메서드를 만들고,
 *       해당 메서드를 호출하여 결과를 화면에 출력해보세요.
 */

public class Method_02 {
	
	public static void holJJak() {
		
		int oddSum = 0, evenSum = 0;
		
		for(int su = 1 ;su <= 100; su++) {
			if (su % 2 == 1) {
				oddSum += su;
			}else if (su % 2 == 0) {
				evenSum += su;
			}
		}
		
		System.out.println("홀수합계 : " + oddSum);
		System.out.println("짝수합계 : " + evenSum);
		
	}

	public static void main(String[] args) {
		holJJak();
	}

}
