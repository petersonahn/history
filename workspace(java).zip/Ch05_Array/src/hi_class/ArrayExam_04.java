package hi_class;

public class ArrayExam_04 {

	public static void main(String[] args) {
		
		int[] arr1 = {10, 20, 30, 40, 50};
		
		for (int k : arr1) {
			System.out.print(k + "\t");
		}
	}

}
