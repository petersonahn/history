package hi_class;

/*
 * 다차원 배열
 * - 1차원 배열이 여러개 묶여있는 형태의 배열을 말함.
 * - 행과 열의 개념이 적용이 됨.
 */
public class ArrayExam_09 {

	public static void main(String[] args) {
		int[][] arr = new int[3][4];
		
		int count = 10;
		
		System.out.println("arr 배열 길이 >>> " + arr.length);
		
		for(int i=0; i < arr.length; i++) {
			for(int j=0; j < arr[i].length; j++) {
				arr[i][j] = count;
				
				count += 10;
				
				System.out.println("arr[" + i + "][" + j + "] >>> " + arr[i][j]);
			}
		}
	}

}
