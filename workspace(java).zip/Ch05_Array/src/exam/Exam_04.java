package exam;

public class Exam_04 {

	public static void main(String[] args) {
		int[][] arr = new int[5][5];
		int su = 1;
		
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				arr[i][j] = su++;
				System.out.printf("%2d\t", arr[i][j]);
			}
			System.out.println();
		}
	}

}
