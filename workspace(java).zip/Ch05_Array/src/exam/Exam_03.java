package exam;

import java.util.Scanner;

public class Exam_03 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
        System.out.print("학생 수를 입력하세요 : ");
		
        
        String[] names = new String[sc.nextInt()]; // 이름 배열
        
        int[] kor = new int[names.length];         // 국어점수 배열
        int[] eng = new int[kor.length];           // 영어점수 배열
        int[] mat = new int[eng.length];           // 수학점수 배열
        int[] sum = new int[mat.length];           // 총점 배열
        double[] avg = new double[sum.length];     // 평균 배열
        String[] grade = new String[avg.length];   // 학점 배열
        int[] rank = new int[grade.length];        // 순위 배열
        
		for(int i = 0; i < names.length; i++) {
			System.out.print("이름 입력 : ");
			names[i] = sc.next();
			System.out.print("국어점수 입력 : ");
			kor[i] = sc.nextInt();
			System.out.print("영어점수 입력 : ");
			eng[i] = sc.nextInt();
			System.out.print("수학점수 입력 : ");
			mat[i] = sc.nextInt();
			
			sum[i] = kor[i] + eng[i] + mat[i];
			avg[i] = sum[i] / 3.0;
			
			if (avg[i] >= 90) {
				grade[i] = "A";
			} else if (avg[i] >= 80) {
				grade[i] = "B";
			} else if (avg[i] >= 70) {
				grade[i] = "C";
			} else if (avg[i] >= 60) {
				grade[i] = "D";
			} else {
				grade[i] = "F";
			}
			
			rank[i] = 1;
		}	
			for(int i = 0; i < rank.length; i++) {
				for(int j=0; j < rank.length; j++) {
					if(sum[j] > sum[i]) {
						rank[i]++;
					}
				}
			}
			
		
			
		
		for(int i=0; i < names.length; i++) {
			System.out.println(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
			System.out.print("이 름 : " + names[i] + "\t");
			System.out.print("총 점 : " + sum[i] + "\t");
			System.out.printf("평 균 : %.2f점\t", avg[i] );
			System.out.print("학 점 : " + grade[i] + "학점\t");
			System.out.print("순 위 : " + rank[i] + "등");
			System.out.println();
		}
		
		
		
		
		sc.close();
	}

}
