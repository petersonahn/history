package exam;

import java.util.Scanner;

public class Exam_02 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int[] sort = new int[5];
		
		System.out.println("5개의 숫자를 입력하세요");
		for(int i = 0; i < 5; i++) {
			
			sort[i] = sc.nextInt();
		}
		
		System.out.println("===내림차순으로 정렬===");
		int temp = 0;
		for(int i = 0; i < sort.length; i++) {
			for(int j=i+1; j < sort.length; j++) {
				if(sort[j] > sort[i]) {
					temp = sort[i];
					sort[i] = sort[j];
					sort[j] = temp;
				}
			}
		}
		
		for(int i = 0; i < sort.length; i++) {
			System.out.print(sort[i] + "\t");
		}
		
		sc.close();
	}

}
