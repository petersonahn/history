package hi_class;

// 자바에서의 출력 양식

public class Basic_06 {

	public static void main(String[] args) {
		// System.out.print();
		// System.out.println();
		// System.out.printf(); // format의 약어
		
		
		// %d : 정수 출력 시 사용되는 format, 10진수
		System.out.printf("%d + %d = %d\n", 10, 20, (10+20)); 
		
		System.out.printf("10을 8진수로 바꾸면 >>> %o\n", 10);
		
		System.out.printf("15를 16진수로 바꾸면 >>> %x\n", 15);
		
		System.out.printf("%f\n", 3.2582);
		
		System.out.printf("%f\n", 3.258217);
		
		System.out.printf("%f\n", 3.14159275123252);
		
		System.out.printf("%.3f\n", 3.14159275123252);
		
		System.out.printf("%d\n", 10000000);
		
		System.out.printf("%,d\n", 10000000);
	}

}
