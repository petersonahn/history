package hi_class;

public class Basic_05 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 숫자 + 숫자 ==> 숫자 (+의 의미는 덧셈의 의미)
		System.out.println(10 + 34);
		
		// 문자 + 숫자 ==> 문자 (+의 의미는 연결의 의미)
		System.out.println("10" + 34);
		
		// 숫자 + 문자 ==> 문자 (+의 의미는 연결의 의미)
		System.out.println(10 + "34");
		
		// 문자 + 문자 ==> 문자 (+의 의미는 연결의 의미)
		System.out.println("10" + "34");
		
		
		System.out.println("10" + (4 + 7));
		System.out.println("10" + 4 + 7);
	}

}
