package hi_class;

/*
 * [문제] 두 개의 변수를 선언하여 각각의 변수에 데이터를 넣은 후
 *       각각의 변수를 콘솔화면에 출력해 주세요.
 *       또한 두 변수에 있는 데이터를 더한 값을 화면에 출력해 주세요.
 */

public class Variable_03 {
	
	public static void main(String[] args) {
		
		int num1 = 5, num2 = 32;
		
		System.out.println("num1 >>> " + num1);
		System.out.println("num2 >>> " + num2);
		System.out.println("num1 + num2 >>> " + (num1 + num2));
		
	}
	
}
