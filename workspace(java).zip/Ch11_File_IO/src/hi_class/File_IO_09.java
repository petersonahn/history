package hi_class;

import java.io.FileReader;
import java.io.FileWriter;


/*
 * [문제] File_IO_05 예제 원본 소스 내용을 복사하여
 *       D:/KDT_JAVA/test/sample.txt 파일에
 *       출력해 주세요.
 */
public class File_IO_09 {

	public static void main(String[] args) throws Exception {
		
		FileReader fr =
				new FileReader
				("D:/KDT_JAVA/workspace(java)/Ch11_File_IO/src/hi_class/File_IO_05.java");
		
		FileWriter fw =
				new FileWriter
				("D:/KDT_JAVA/test/sample.txt");
		
		while(true) {
			
			int readByte = fr.read();
			
			if(readByte == -1) {
				
				break;
				
			}
			
			fw.write(readByte);
						
		}
		fw.close(); fr.close();
	}

}
