package hi_class;

import java.io.FileInputStream;
import java.io.InputStream;

/*
 * [문제] C:/Windows/system.ini 파일을 파일 입출력을
 *       통하여 읽어들인 후 콘솔창에 출력해보세요.
 */


public class File_IO_04 {

	public static void main(String[] args) {
		
		InputStream is = null;
        try {
			
		is = new FileInputStream("C:/Windows/system.ini");
		
		while(true) {
			
			int readByte = is.read();
			
			if(readByte == -1) {
				
				break;
				
			}
			
			System.out.print((char)readByte);
		}
			
		} catch (Exception e) {
			
			e.printStackTrace();
			
		}
		
		
	}

}
