package hi_class;


import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

/*
 * [문제] File_IO_05 예제 클래스를 읽어 들여서
 *       콘솔창에 출력해보세요.
 *       D:\KDT_JAVA\workspace(java)\Ch11_File_IO\src\hi_class\File_IO_05.java
 */

public class File_IO_06 {

	public static void main(String[] args) {
		
		Reader reader = null;
		
		try {
			reader = new FileReader
					("D:/KDT_JAVA/workspace(java)/Ch11_File_IO/src/hi_class/File_IO_05.java");
			
			while(true) {
				
				int readCount = reader.read();
				
				if(readCount == -1) {
					
					break;
					
				}
				
				System.out.print((char)readCount);
			}
		} catch (Exception e) {

			e.printStackTrace();
		} finally {
			try {
				reader.close();
			} catch (IOException e) {
 
				e.printStackTrace();
			}
		}
		
				
		
	}

}
