package hi_class;


interface SuperA {
	
	// 반환타입(X), 매개변수(X)
	void method1();
}

interface SuperB {
	
	// 반환타입(X), 매개변수(O)
	void method2(int su);
}

interface SuperC {
	
	// 반환타입(O), 매개변수(X)
	int method3();
}

interface SuperD {
	
	// 반환타입(O), 매개변수(O)
	double method4(int su1, double su2);
}

public class Lambda_02 {

	public static void main(String[] args) {
		
	// 1-1. 일반적으로 객체 생성
	//      ==> 반환타입(X), 매개변수(X)
		SuperA a1 = new SuperA() {
			
			@Override
			public void method1() {
				System.out.println("무명 클래스 ==> 반환타입(X), 매개변수(X) 메서드");
			}
		};
		
		a1.method1();  // 무명 클래스의 메서드 호출
		System.out.println();
		
		
	// 1-2. 람다식으로 표현하는 방법
		SuperA a2 = () -> {      // () 안에 아무것도 없는 것은 매개변수가 없기 때문
			System.out.println("람다식 ==> 반환타입(X), 매개변수(X) 메서드");
		};
		
		a2.method1();   // 람다식으로 메서드를 호출
		
		
	// 람다식에서 메서드 호출 시 실행 문장이 한 줄인 경우 { } 생략 가능!! 
		SuperA a3 = () ->      
			System.out.println("람다식 ==> 반환타입(X), 매개변수(X) 메서드");
			
		a3.method1();
		System.out.println();
		
		
	// 2-1. 일반적으로 객체 생성
	//     ==> 반환타입(X), 매개변수(O)
		
		SuperB b1 = new SuperB() {
			
			@Override
			public void method2(int su) {
				System.out.println("무명 클래스 ==> 반환타입(X), 매개변수(O) 메서드 / su >>> " + su);
				
			}
		};
		
		b1.method2(47);
		System.out.println();
		
		
	// 2-2. 람다식으로 표현하는 방법
		SuperB b2 = (int su) -> {
			System.out.println("람다식 ==> 반환타입(X), 매개변수(O) 메서드 / su >>> " + su);
		};
		
		b2.method2(88);
		System.out.println();
		
		
	// 매개변수가 있는 경우 매개변수의 타입 생략 가능
		SuperB b3 = (su) -> {   
			System.out.println("람다식 ==> 반환타입(X), 매개변수(O) 메서드 / su >>> " + su);
		};
		
		b3.method2(47);
		
		
	// 람다식에서 메서드 호출 시 실행 문장이 한 문장인 경우 { } 생략 가능
		SuperB b4 = (su) ->    
			System.out.println("람다식 ==> 반환타입(X), 매개변수(O) 메서드 / su >>> " + su);
		
		b4.method2(88);
		System.out.println();
		
		
	// 람다식에서 메서드 호출 시 매개변수가 하나이면 ( ) 생략 가능
		SuperB b5 = su ->    
		System.out.println("람다식 ==> 반환타입(X), 매개변수(O) 메서드 / su >>> " + su);
	
		b5.method2(47);
		System.out.println();
		
		
	// 3-1. 일반적으로 객체 생성 
	//     ==> 반환타입(O), 매개변수(X)
		SuperC c1 = new SuperC() {
			
			@Override
			public int method3() {
				
				return 27;
			}
		};
		System.out.println("무명 클래스 ==> 반환타입(O), 매개변수(X) 메서드 >>> " + c1.method3());
		System.out.println();
		
		
	// 3-2. 람다식으로 표현하는 방법
		SuperC c2 = () -> {
			return 76;
		};
		System.out.println("람다식 ==> 반환타입(O), 매개변수(X) 메서드 >>> " + c2.method3());
		System.out.println();
		
		
	// 메서드 호출 시 return 문장이 한 문장이면 return 키워드와 { } 가 생략 가능
		SuperC c3 = () -> 23;
		
		System.out.println("람다식 ==> 반환타입(O), 매개변수(X) 메서드 >>> " + c3.method3());
		System.out.println();
		
		
	// 4-1. 일반적으로 객체 생성
	//     ==> 반환타입(O), 매개변수(O)
		SuperD d1 = new SuperD() {
			
			@Override
			public double method4(int su1, double su2) {
				
				return su1 + su2;
			}
		};
		System.out.println("무명 클래스 ==> 반환타입(O), 매개변수(O) 메서드 / " + d1.method4(40, 128));
		System.out.println();
		
		
	// 4-2. 람다식으로 표현하는 방법
		SuperD d2 = (int su1, double su2) -> {
			return su1 + su2;
		};
		System.out.println("람다식 ==> 반환타입(O), 매개변수(O) 메서드 / " + d2.method4(11, 34));
		System.out.println();
		
	// 매개변수의 타입은 생략해도 됨
		SuperD d3 = (su1, su2) -> {
			return su1 + su2;
		};
		System.out.println("람다식 ==> 반환타입(O), 매개변수(O) 메서드 / " + d3.method4(40, 77));
		System.out.println();
		
		
	// 메서드 호출 시 return문이 한 문장이면 { }와 return 키워드 생략 가능
		SuperD d4 = (su1, su2) -> su1 + su2;
		
		System.out.println("람다식 ==> 반환타입(O), 매개변수(O) 메서드 / " + d4.method4(11, 34));
		System.out.println();
	}

}
