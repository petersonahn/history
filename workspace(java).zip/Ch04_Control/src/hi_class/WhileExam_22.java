package hi_class;

// ABCDEFGHIJKLMNOPQRSTUVWXYZ
// ZYXWVUTSRQPONMLKJIHGFEDCBA
public class WhileExam_22 {

	public static void main(String[] args) {
		char alpha1 = 'A';
		
		while(alpha1 <= 'Z') {
			System.out.print(alpha1);
			
			alpha1++;
		}
		
		System.out.println();
		
		
	    char alpha2 = 'Z';
	    
	    while(alpha2 >= 'A') {
			System.out.print(alpha2);
			
			alpha2--;
		}
		
		System.out.println();
	
	}

}
