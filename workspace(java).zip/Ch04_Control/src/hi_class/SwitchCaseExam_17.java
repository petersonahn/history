package hi_class;

import java.util.Scanner;

public class SwitchCaseExam_17 {

	public static void main(String[] args) {
		
		// 1. 키보드로 데이터 입력 준비 작업.
		Scanner sc = new Scanner(System.in);
		
		// 2-1. 키보드로 이름을 입력을 받자.
		System.out.print("이름을 입력하세요. : ");
		String name = sc.next();
		
		// 2-2. 키보드로 국어점수를 입력을 받자.
		System.out.print("국어점수를 입력하세요. : ");
		int kor = sc.nextInt();
		
		// 2-3. 키보드로 영어점수를 입력을 받자.
		System.out.print("영어점수를 입력하세요. : ");
		int eng = sc.nextInt();
		
		// 2-4. 키보드로 자바점수를 입력을 받자.
		System.out.print("자바점수를 입력하세요. : ");
		int java = sc.nextInt();
		
		System.out.println();
		
		// 3. 총점을 구하자.
		// 총점 = 국어점수 + 영어점수 + 자바점수
		int sum = kor + eng + java;
		
		// 4. 평균을 구하자.
		// 평균 = 총점 / 과목 수
		double avg = sum / 3.0;
		
		// 5. 학점을 구하자.
		// 학점은 평균을 가지고 구함. ==> 다중 if~else 문 이용
		String grade;
		
		switch((int)(avg/10)) {
			case 10 :
			case 9 :
					grade = "A학점";
					break;
			case 8 :
					grade = "B학점";
					break;
			case 7 :
					grade = "C학점";
					break;
			case 6 :
					grade = "D학점";
					break;
			default :
					grade = "F학점";
		}
		
		// 6. 성적 처리한 결과를 화면에 출력해 보자.
		System.out.println("이   름 : " + name);
		System.out.println("국어점수 : " + kor + "점");
		System.out.println("영어점수 : " + eng + "점");
		System.out.println("자바점수 : " + java + "점");
		System.out.println("총   점 : " + sum + "점");
		System.out.printf("평   균 : %.2f점\n", avg);
		System.out.println("학   점 : " + grade);
		
		sc.close();
	}

}
