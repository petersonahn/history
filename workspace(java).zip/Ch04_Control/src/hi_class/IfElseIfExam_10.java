package hi_class;

import java.util.Scanner;

/*
 * 3. 다중 if ~ else 문 - 분기문(조건문)
 *    - 여러 개의 조건 중에 맞는 조건에 해당하는 문장을 실행하는 구조.
 *    
 *    형식)
 *          if(조건식1){
 *               조건식1이 참인 경우 실행문장;
 *          }else if(조건식2){
 *               조건식1은 거짓이고, 조건식2는 참인 경우 실행문장;
 *          }else if(조건식3){
 *               조건식1, 조건식2이 거짓이고 조건식3이 참인 경우 실행문장;
 *          }else{
 *                조건식1, 조건식2, 조건식3이 모두 거짓인 경우 실행문장;
 *          }
 */
public class IfElseIfExam_10 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("1 ~ 3 사이의 숫자 중에서 하나를 선택. : ");
		
		int su = sc.nextInt();
		
		if(su == 1) {
			System.out.println("입력받은 숫자는 1입니다.");
		}else if(su == 2) {
			System.out.println("입력받은 숫자는 2입니다.");
		}else if(su == 3) {
			System.out.println("입력받은 숫자는 3입니다.");
		}else{
			System.out.println("1 ~ 3 이외의 숫자가 입력되었습니다.");
		}
		sc.close();
	}

}
