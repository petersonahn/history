package hi_class;

/*
 * 4. switch ~ case 문 - 분기문(조건문)
 *    - 식(정수 또는 char)을 사용하여 여러 개의 조건 중
 *      하나를 선택하는 명령문.
 *    - jdk 1.7 버전 이상부터는 식에 String(문자열) 사용이 가능함.
 *    
 *    형식)
 *            switch(식 또는 값 또는 변수) {
 *               case 값1 :
 *                     값1일때 실행문;
 *                     break;         // switch~case문 탈출
 *               case 값2 :
 *                     값2일때 실행문;
 *                     break;         // switch~case문 탈출
 *               case 값3 :
 *                     값3일때 실행문;
 *                     break;         // switch~case문 탈출
 *               default :
 *                     값1 ~ 값3 이외의 값이 들어온 경우 실행문;
 *                     // 해당 default 문장은 생략도 가능함.
 *            }      
 */

public class SwitchCaseExam_13 {

	public static void main(String[] args) {
		
	}

}
