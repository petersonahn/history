package hi_class;

import java.util.Scanner;

/*
 * [문제] 키보드로부터 압력 받은 정수가
 *       홀수인지 아니면 짝수인지 판별하여 화면에 출력해 보세요.
 */
public class IfElseExam_08 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("정수 하나를 입력해주세요 : ");
		
		int num = sc.nextInt();
		
		if(num > 0 && num % 2 == 1) {
			System.out.println("입력받은 " + num + "은(는) 홀수입니다.");
		} else if(num > 0 && num % 2 == 0) {
			System.out.println("입력받은 " + num + "은(는) 짝수입니다.");
		}else if(num == 0) {
			System.out.println( num + "입니다.");
		} else {
			System.out.println("입력받은 " + num + "은(는) 음수입니다.");
		}
		
		sc.close();
	}

}
