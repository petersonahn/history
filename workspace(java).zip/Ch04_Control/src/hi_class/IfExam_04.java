package hi_class;

import java.util.Scanner;

/*
 * [문제] 키보드로 입력 받은 정수 값이 음수이면
 *       "입력받은 정수는 음수입니다." 라는 메세지를 화면에 출력해보세요.
 */

public class IfExam_04 {

	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
		
		System.out.print("정수를 입력하세요 : ");
		
		int su = sc.nextInt();
		
		if (su < 0) {
			System.out.println("입력받은 " + su +"은(는) 음수입니다.");
		}
		
		sc.close();
	}

}
