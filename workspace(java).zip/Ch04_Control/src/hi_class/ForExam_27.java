package hi_class;

/*
 * 1 ~ 100까지의 홀수의 합과
 * 짝수의 합을 구하여 화면에 출력해보세요.
 */
public class ForExam_27 {

	public static void main(String[] args) {
        int hol = 0, jjak = 0 ;
		
		for(int su = 1 ;su <= 100; su++) {
			if (su % 2 == 1) {
				hol += su;
			}else if (su % 2 == 0) {
				jjak += su;
			}
		}
		
		System.out.println("1 ~ 100 까지의 홀수의 합 >>> " + hol);
		System.out.println("1 ~ 100 까지의 짝수의 합 >>> " + jjak);
	}

}
