package hi_class;

import java.util.Scanner;

/* 키보드로부터 입력 받은 정수가 5의 배수이면
   "이 정수는 5의 배수입니다." 라는 메세지를
   아니면 " 이 정수는 5의 배수가 아닙니다." 라는
   메세지를 화면에 출력해 보세요.
   단, 입력 받은 정수가 음수인 경우에는
   "음수가 입력 되었습니다." 라는 메세지를 화면에
   출력해 주세요. 
*/
public class IfElseExam_09 {

	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
		
		System.out.print("정수 하나를 입력하세요 : ");
		
		int su = sc.nextInt();
		
		if (su > 0 && su % 5 == 0) {
			System.out.println("입력받은 " + su + "은(는) 5의 배수입니다.");
		} else if (su > 0 && su % 5 != 0) {
			System.out.println("입력받은 " + su + "은(는) 5의 배수가 아닙니다.");
		} else if (su == 0) {
			System.out.println(su + "이 입력되었습니다.");
		} else if (su < 0) {
			System.out.println("입력받은 " + su + "은(는) 음수입니다.");
		}
		
		sc.close();
	}

}
