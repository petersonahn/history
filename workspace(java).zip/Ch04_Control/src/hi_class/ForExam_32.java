package hi_class;

/*
 * 아래와 같이
 */
public class ForExam_32 {

	public static void main(String[] args) {
		for(int i = 1; i < 5; i++) {
			
			for(int j = 1; j < 8; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		
		System.out.println();
		System.out.println();
		
        for(int i = 1; i < 6; i++) {
			
			for(int j = 1; j <= i; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		
		System.out.println();
		System.out.println();
		
        for(int i = 5; i >= 1; i--) {
			
			for(int j = 1; j <= i; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		
		System.out.println();
		System.out.println();
	}

}
