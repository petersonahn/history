package hi_class;

import java.util.Scanner;

public class ForExam_28 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
        System.out.print("정수 하나를 입력하세요. : ");
		
		int max = sc.nextInt();
		int hol = 0, jjak = 0;
		
		for(int su = 1 ;su <= max; su++) {
			if (su % 2 == 1) {
				hol += su;
			}else if (su % 2 == 0) {
				jjak += su;
			}
		}
		
		System.out.println("1 ~ "+ max + "까지의 홀수의 합 >>> " + hol);
		System.out.println("1 ~ "+ max + "까지의 짝수의 합 >>> " + jjak);
		
		sc.close();
	}

}
