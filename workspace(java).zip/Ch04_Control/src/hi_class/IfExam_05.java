package hi_class;

import java.util.Scanner;

/*
 * [문제] 키보드로 입력받은 점수가 60점 이상이면 "합격입니다."
 *       라는 메세지를 화면에 출력해보세요.
 */

public class IfExam_05 {

	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
		
		System.out.print("점수를 입력하세요 : ");
		
		int score = sc.nextInt();

		if(score >= 60) {
			System.out.println("합격입니다.");
		}
		
		
		sc.close();
	}

}
