package hi_class;
/*
 * do while 반복문
 * - 먼저 반복 실행문을 실행을 하고 난 후 조건식을 비교하는 명령문.
 * 
 * 형식) 
 *       do {
 *           반복 실행 문장;
 *       }while(조건식);
 */


public class DoWhileExam_25 {

	public static void main(String[] args) {
		int su = 1;
		
		do {
			System.out.println("su >>> " + su);
			
			su++;
			
		}while(su <= 10);
	}

}
