package hi_class;

import java.util.Scanner;

/*
 * [문제] 키보드로 정수 하나를 입력받아서 입력받은 정수가
 *       5의 배수이면 "이 정수는 5의 배수입니다." 라는
 *       메세지를 화면에 출력해보세요.
 */

public class IfExam_03 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("정수를 입력하세요 : ");
		
		int su = sc.nextInt();
		
		if (su % 5 == 0) {
			System.out.println("이 정수는 5의 배수입니다.");
		}
		sc.close();
	}

}
