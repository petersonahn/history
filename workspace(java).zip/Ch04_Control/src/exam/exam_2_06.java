package exam;

import java.util.Scanner;

public class exam_2_06 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("*** Coffee 메뉴 ***");
		System.out.println("1. 아메리카노 - 3,000원");
		System.out.println("2. 카페라떼 - 4,000원");
		System.out.println("3. 마키아또 - 4,500원");
		System.out.println("4. 바닐라라떼 - 4,500원");
		
		System.out.print("위 메뉴 중 하나를 선택하세요. : ");
		int menu = sc.nextInt(); 
		String menu1 = "";
		int dan = 0;
		if (menu == 1) {
			menu1 = "아메리카노";
			dan = 3000;
		} else if (menu == 2) {
			menu1 = "카페라떼";
			dan = 4000;
		} else if (menu == 3) {
			menu1 = "마키아또";
			dan = 4500;
		} else if (menu == 4) {
			menu1 = "바닐라라떼";
		    dan = 4500;
		}
		
		System.out.print("주문 수량을 입력하세요. : ");
		int su = sc.nextInt();
		System.out.print("입금액을 입력하세요. : ");
		int deposit = sc.nextInt();
		
		
		System.out.println("주문한 메뉴 : " + menu1);
		System.out.printf("커피 단가 : %,d원\n" , dan);
		System.out.println("주문 수량 : " + su);
		System.out.printf("입 금 액 : %,d원\n" , deposit);
		System.out.printf("공급가액 : %,d원\n" , (dan*su));
		System.out.printf("부가세액 : %,d원\n" , ((dan*su)/10));
		System.out.printf("총 금 액 : %,d원\n" , ((dan*su)+((dan*su)/10)));
		System.out.printf("거스름돈 : %,d원\n" , (deposit - ((dan*su)+((dan*su)/10))));
				
		sc.close();
	}

}
