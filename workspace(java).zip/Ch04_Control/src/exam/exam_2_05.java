package exam;

public class exam_2_05 {

	public static void main(String[] args) {
		int i = 1, oddSum = 0, evenSum = 0;
		while (i <= 100) {
			
		    if(i % 2 == 1) {		    	
			    oddSum += i;
		    }else if(i % 2 == 0) {
			    evenSum += i;
		    }
		    i++;
		}
		System.out.println("hap ==> " + (oddSum-evenSum));
	}

}
