package exam;

import java.util.Scanner;

public class exam_02 {

	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
		
		System.out.print("임의의 정수를 입력하세요. : ");
		
		int su = sc.nextInt();
		
		System.out.println("입력 받은 정수 >>> " + su);
		System.out.println(su + " 의 제곱 >>> " + (su*su));
		System.out.println(su + " 의 세제곱 >>> " + (su*su*su));
		
		sc.close();
	}

}
