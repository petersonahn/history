package exam;

import java.util.Scanner;

public class exam_2_01 {

	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in) ;
		
        System.out.print("지방의 그램을 입력하세요 : ");
        int ji = sc.nextInt();
        System.out.print("탄수화물의 그램을 입력하세요 : ");
        int tan = sc.nextInt();
        System.out.print("단백질의 그램을 입력하세요 : ");
        int dan = sc.nextInt();
        
        System.out.printf("총칼로리 : %,d cal\n" , ((ji * 9) + (tan * 4) + (dan * 4)));
        
        sc.close();
	}

}
