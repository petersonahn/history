package exam;

import java.util.Scanner;

public class exam_2_02 {

	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
		
        System.out.print("수 입력 : ");
		
		int max = sc.nextInt();
		int hol = 0, jjak = 0;
		
		for(int su = 1 ;su <= max; su++) {
			if (su % 2 == 1) {
				hol += su;
			}else if (su % 2 == 0) {
				jjak += su;
			}
		}
		
		System.out.println("홀수합계 : " + hol);
		System.out.println("짝수합계 : " + jjak);
		
		sc.close();
	}

}
