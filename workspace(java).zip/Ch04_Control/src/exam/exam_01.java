package exam;

import java.util.Scanner;

public class exam_01 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("국어 점수 입력 : ");
		
		int kor = sc.nextInt();
		
        System.out.print("영어 점수 입력 : ");
		
		int eng = sc.nextInt();
		
		System.out.print("수학 점수 입력 : ");
		
		int math = sc.nextInt();
		
        System.out.print("자바 점수 입력 : ");
        
        int java = sc.nextInt();
        
        int sum = kor + eng + math + java;
        
        double avg = sum / 4.0;
        
        System.out.println("국어점수 : " + kor + " 점"); 
		System.out.println("영어점수 : " + eng + " 점");
		System.out.println("수학점수 : " + math + " 점");
		System.out.println("자바점수 : " + java + " 점"); 
		System.out.println("총   점 : " + sum + " 점"); 
		System.out.printf("평   균 :  %.2f점\n", avg);
		
		sc.close();
	}

}
