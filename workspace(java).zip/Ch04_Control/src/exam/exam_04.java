package exam;

import java.util.Scanner;

public class exam_04 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in) ;
		
        System.out.print("임의의 4자리 숫자 입력 : ");
		
		int su = sc.nextInt();
		int ft = su / 5000;
		int t = (su % 5000) / 1000 ;
		int fh = (su % 1000) / 500;
		int h = (su % 500) / 100;
		int fif = (su % 100) / 50;
		int ten = (su % 50) / 10;
		int one = su % 10;
		System.out.println("입력받은 숫자 ==> " + su);
		System.out.println("오천원 지폐 : " + ft + "장");
		System.out.println("천원 지폐 : " + t + "장");
		System.out.println("오백원 동전 : " + fh + "개");
		System.out.println("백원 동전 : " + h + "개");
		System.out.println("오십원 동전 : " + fif + "개");
		System.out.println("십원 동전 : " + ten + "개");
		System.out.println("일원 동전 : " + one + "개");
		
		sc.close();
	}

}
