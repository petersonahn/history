package exam;

public class exam_2_04 {

	public static void main(String[] args) {
        for(char i = 'Z'; i >= 'A'; i--) {
			
			for(char j = 'A'; j <= i; j++) {
				System.out.print(j);
			}
			System.out.println();
		}
	}

}
