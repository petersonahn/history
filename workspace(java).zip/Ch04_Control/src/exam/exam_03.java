package exam;

import java.util.Scanner;

public class exam_03 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("입금액 입력 : ");
		int deposit = sc.nextInt();
		System.out.print("상품 단가 입력 : ");
		int dan = sc.nextInt();
		System.out.print("상품 수량 입력 : ");
		int su = sc.nextInt();
		
		int sup = dan * su;
		int bu = (dan * su) / 10;
		int sum = (dan * su) + bu;
		
		System.out.println("지불한 금액 : " + deposit + "원");
		System.out.println("제품단가 : " + dan + "원");
		System.out.println("수량 : " + su);
		System.out.println("공급가액 : " + sup + "원");
		System.out.println("부가세 : " + bu + "원");
		System.out.println("상품총액 : " + sum + "원");
		System.out.println("거스름 돈 : " + (deposit - sum) + "원");
		
		sc.close();
	}

}
