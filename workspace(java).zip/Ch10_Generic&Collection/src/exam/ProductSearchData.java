package exam;

import java.util.HashMap;
import java.util.Map;

public class ProductSearchData {
	
	Map<String, String> proMap = 
			new HashMap<String, String>();

	public ProductSearchData() {				
		proMap.put("세탁기", "드럼 세탁기 최신형");
		proMap.put("냉장고", "지펠 냉장고 최신형");
		proMap.put("TV", "HDTV 150인치 최신 모델");		
	}
	
	String search(String productName) {
		
						
		if(proMap.containsKey(productName)) {
			return proMap.get(productName);
		} else {
			return null;
		}
		
		
	}
}
