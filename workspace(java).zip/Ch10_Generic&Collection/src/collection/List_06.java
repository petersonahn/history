package collection;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import model.Student;

/*
 * [문제] List_05 클래스처럼 Student 객체를 만들어서
 *       키보드로 학생 수를 입력을 받고, 입력받은
 *       학생 수만큼 학생의 정보를 입력받아서 ArrayList에
 *       저장 후 화면에 출력해보세요.
 *       (학생 정보 - 학번, 이름, 학과, 연락처, 주소)
 */

public class List_06 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("학생 수를 입력하세요 : ");
		int studentCount = sc.nextInt();
		
		List<Student> list =new ArrayList<Student>();
		
		sc.nextLine();
		
		// 1. 키보드로 학생 수만큼 반복하여 학생 정보를 키보드로
		//    입력을 받아서 ArrayList에 저장을 해보자.
		for(int i=0; i<studentCount; i++) {
			System.out.println(
					(i+1) + " 번째 학생의 학번, 이름, 학과, 연락처, 주소를 입력하세요.....");
			Student student = new Student(sc.nextLine(), sc.nextLine(), 
					sc.nextLine(), sc.nextLine(), sc.nextLine());
			
			list.add(student);
		}
		
		// 2. 학생 정보를 ArrayList에서 가져와서 화면에 출력해 보자.
		for(int i=0; i<studentCount; i++) {
			
			Student addr = list.get(i);
			
			System.out.println(addr.getHakbun() + "\t" + addr.getName() + "\t" + 
					addr.getMajor() + "\t" + addr.getPhone() + "\t" + addr.getAddr());
			
			System.out.println(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
			
		}
		sc.close();
	}

}
