package collection;

import java.util.ArrayList;
import java.util.List;

/*
 * 컬렉션 프레임워크
 * - 컬렉션의 사전적 의미 : 수집해서 모으다, 저장한다는 의미.
 * - 자바에서 배열은 여러 개의 데이터를 다루는데 편리한 자료구조이지만,
 *   삽입과 삭제가 빈번하고, 데이터의 크기를 예측할 수 없는 응용
 *   프로그램에서는 사용하기가 어려움.
 *   예를 든다면 많은 사람의 이름과 전화번호를 저장하고 삽입, 삭제가
 *   빈번한 전화번호부 관리 프로그램에서 배열을 사용한다면 프로그램 
 *   작성에 어려움을 겪게 됨.
 * - 자바에서의 컬렉션은 데이터의 추가, 삭제, 수정, 검색 등을 
 *   효과적으로 제공해 주는 자료구조 관련 클래스임.
 *   ==> 값을 담을 수 있는 그릇을 의미함(컨테이너 개념).
 * - java.util 패키지에 포함이 되어 있음.
 * - 인터페이스를 통해서 정형화된 방법으로 다양한 컬렉션 클래스를 이용.
 * 
 * - 컬렉션 프레임워크.
 *   1) 컬렉션을 표준화하여 설계해 놓은 인터페이스.
 *   2) List 계열, Set 계열, Map 계열
 *   
 * - 컬렉션의 특징
 *   1) 컬렉션은 제네릭(generic) 이라는 기법으로 만들어져 있음.
 *      컬렉션 클래스의 이름에는 <E>, <K>, <V> 등이 항상 포함되어
 *      있음. 이들을 타입 매개변수라고 함. 해당 위치에 구체적인 타입을
 *      명시하여 해당 타입만 저장할 수 있음.
 *   2) 컬렉션의 요소는 객체들만 사용이 가능함. 일반 기본 타입의
 *      자료형은 컬렉션 요소로 사용이 불가능함.
 */

/*
 * ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
 * ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
 * ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
 * 1. List 계열의 컬렉션 프레임워크의 특징
 *    - 자료의 순서가 보장(index 가 있음) : 정렬 기능 제공.
 *    - 중복 데이터 허용.
 *    - List 인터페이스의 자식클래스로 구현
 *      ==> ArrayList(O), LinkedList(가끔)
 *          Vector(가끔 - 멀티쓰레드에서 특화되어 있음)
 *    - 특히 DB에 데이터를 레코드 단위로 저장하거나,
 *      저장된 데이터를 가져올 경우에 많이 사용이 됨.
 * ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
 * ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
 * ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★    
 */

public class List_02 {

	public static void main(String[] args) {
		
		// List 계열 컬렉션 객체 생성.
		List<String> list = new ArrayList<String>();
		
		// 1. add("데이터") : 데이터를 추가해 주는 메서드.
		list.add("홍길동");
		list.add("세종대왕");   // 중복 데이터
		list.add("유관순");
		list.add("이순신");
		list.add("신사임당");
		list.add("세종대왕");  // 중복 데이터
		
		// 2. size() : 데이터의 크기를 정수값으로 반환해주는 메서드.
		System.out.println("list 크기 >>> " + list.size());
		System.out.println();
		// 3. get(index) : List에 저장되어 있는 데이터를 가져오는 메서드.
		System.out.println("list[1] 데이터 >>> " + list.get(1));
		System.out.println();
		// List에 있는 전체 데이터를 가져오고 싶은 경우.
		for(int i=0; i<list.size(); i++) {
			System.out.println("list[" + i + "] >>> " + list.get(i));
		}
		System.out.println();
		// 4. clear() : list에 있는 모든 데이터를 삭제하는 메서드.
		list.clear();
		System.out.println("list 크기 >>> " + list.size());
		System.out.println();
		
		// 5. isEmpty() : list가 비어있는지 혹은 아닌지를 체크하는 메서드.
		//                ==> 반환형은 boolean 타입.
		
		System.out.println("list isEmpty()? >>> " + list.isEmpty());
		System.out.println();
		
		list.add("홍길동");
		list.add("세종대왕");  
		list.add("유관순");
		list.add("이순신");
		list.add("신사임당");
		list.add("세종대왕");
		
		// 6. remove(index) : list의 특정 요소(인덱스)를 제거하는 메서드.
		//                    다음 index 부터 index 값이 하나씩 당겨진다.
		list.remove(1);
		for(int i=0; i<list.size(); i++) {
			System.out.println("list[" + i + "] >>> " + list.get(i));
		}
	    System.out.println();
		
		// 7. add(index, element(값))
		//    ==> list의 특정 index에 데이터를 추가하는 메서드.
		//    해당 index에 추가가 되고, 기존에 있던 데이터들은
		//    index가 하나씩 뒤로 밀림.
		list.add(1, "강감찬");
		for(int i=0; i<list.size(); i++) {
			System.out.println("list[" + i + "] >>> " + list.get(i));
		}
		
		
	}
}
