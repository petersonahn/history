package collection;

public class Coin {
	
	private int coin;
	
	public Coin() { }  // 기본 생성자
	
	public Coin(int coin) { 
		this.coin = coin;
	}  // 인자 생성자

	public int getCoin() {
		return coin;
	}

	public void setCoin(int coin) {
		this.coin = coin;
	}
}
