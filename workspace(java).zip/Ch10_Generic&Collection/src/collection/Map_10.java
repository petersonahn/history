package collection;

import java.util.HashMap;
import java.util.Map;

/*
 * 3. Map 컬렉션 프레임워크 특징
 *    - key, value를 한쌍으로 해서 데이터를 저장하고
 *      검색하는 기능을 제공함.
 *    - key는 중복불가, value는 중복가능함.
 *    - Map 인터페이스의 자식 클래스를 이용하여 구현.
 *      ==> HashMap(O), HashTable(O),
 *          Properties(가끔), TreeMap(X)
 */

public class Map_10 {

	public static void main(String[] args) {

		// Map 인터페이스의 자식 클래스를 이용하여 객체 생성.
		Map<String, Integer> map = 
				new HashMap<String, Integer>();
		
		// 1. put(key, value) : map에 저장하는 메서드.
		//    ==> 이름을 key로 저장, 점술르 value(값)로 저장.
		map.put("홍길동", 92);
		map.put("세종대왕", 100);
		map.put("유관순", 95);
		map.put("이순신", 88);
		map.put("신사임당", 91);
		
		// 2. get(key) : map에 저장된 데이터를 가져오는 메서드.
		//               get(key) 메서드를 호출하면 인자(key)에
		//               해당하는 value 값을 반환해주는 메서드.
		System.out.println("세종대왕 점수 >>> " + map.get("세종대왕") + "점");
		System.out.println();
		
		// keySet() : map 데이터 중에서 key들만 뽑아서
		//            Set 객체로 반환시키는 메서드.
		
		for(String name : map.keySet()) {
			System.out.println(name + " 님의 점수 >>> " + map.get(name) + "점");
		}
	}

}
