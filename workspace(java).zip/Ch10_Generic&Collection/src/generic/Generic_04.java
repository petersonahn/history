package generic;

public class Generic_04 {

	public static void main(String[] args) {

		// Integer 타입의 클래스 객체 생성
		Generic<Integer> it = new Generic<Integer>();
		Integer[] iarr = {10, 20, 30, 40, 50};
		
		Integer ivar = 150;
		
		it.setArr(iarr);
		it.setVar(ivar);
		it.output();
		System.out.println();
		
		// String 타입의 클래스 객체 생성
		Generic<String> st =new Generic<String>();
		
		String[] str = {"홍길동", "세종대왕", "유관순", "이순신", "신사임당"};
		
		String var = "김유신";
		
		st.setArr(str);
		st.setVar(var);
		st.output();
	}

}
