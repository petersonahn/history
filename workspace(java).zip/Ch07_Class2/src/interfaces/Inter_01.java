package interfaces;

public class Inter_01 {

	public static void main(String[] args) {
		
		Sub sub = new Sub();
		
		// interface로 변경되는 순간
		// 해당 변수는 static final
		// 키워드가 붙은 상수로 변한다.
		// 그래서 상수값을 변경하는 것은 불가능.
		// sub.num = 157;
		
		sub.output1();
		
		sub.output2();

	}

}
