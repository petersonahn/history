package interfaces;

interface Camera {
	
	void photo();
}

interface Tv {
	
	void TvView();
}

interface MP3 {
	
	void playMusic();
}

class MyPhone implements Camera, Tv, MP3 {

	@Override
	public void playMusic() {
		System.out.println("핸드폰으로 음악을 들어요~~~");
		
	}

	@Override
	public void TvView() {
		System.out.println("핸드폰으로 TV를 봐요~~~");
		
	}

	@Override
	public void photo() {
		System.out.println("핸드폰으로 사진을 찍어요~~~");
		
	}
	
}

public class Main_03 {

	public static void main(String[] args) {
		MyPhone phone = new MyPhone();
		
		phone.photo(); phone.TvView(); phone.playMusic();
	}

}
