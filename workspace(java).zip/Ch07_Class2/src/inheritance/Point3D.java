package inheritance;

public class Point3D extends Point{
	
	// int x;
	// int y;
	int z;
	
	public Point3D() {
		super();
	}
	
	public Point3D(int x, int y) {
		
		super(x, y);          // 부모 클래스의 인자 생성자 호출
		
		//this.x = x;
		//this.y = y;
		
	}  // 인자 생성자
	
    public Point3D(int x, int y, int z) {
    	
		this(x, y);    	// 항상 첫줄에
    	// this.x = x;
		// this.y = y;
		this.z = z;
		
	} // 인자 생성자
    
    void getPoint3DInfo() {
    	
    }
}
