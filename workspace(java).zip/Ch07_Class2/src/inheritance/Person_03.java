package inheritance;

public class Person_03 {

	public static void main(String[] args) {
		
		Student student = 
				new Student("001101-3312347", "홍길동", 25, "대학생", "경제학과");
		
		student.getStudentInfo();
		
		System.out.println();
		
		Employee employee = new Employee();
		
		employee.juminNo = "960505-2345678";
		
		employee.name = "홍길동";
		
		employee.age = 28;
		
		employee.job = "회사원";
		
		employee.salary = 500;
		
		employee.getEmployeeInfo();
		
	}

}
