package exam1;

public class Temporary extends Employee {

	// 멤버변수
	int time;                // 작업 시간
	int pay;                 // 시간당 급여
	
	public Temporary() {  }  // 기본 생성자
	
	public Temporary(String name, int time, 
				int pay) {
		
		this.name = name;
		this.time = time;
		this.pay = pay;
		
	}  // 인자 생성자
	
	
	// 부모 클래스의 추상메서드 재정의.
	@Override
	int getPays() {
		// 급여 계산 : 작업 시간 * 시간당 급여
		return time * pay;
	}

}
