package overriding;

public class Elephant extends Animal {

	@Override
	void sound() {
		System.out.println("뿌우우~~~");
	}
	
}
