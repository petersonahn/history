package overriding;

public class Animal_01 {

	public static void main(String[] args) {
		
		Dog dog = new Dog();
		Cat cat = new Cat();
		Elephant elephant = new Elephant();
		
		dog.sound();
		cat.sound();
		elephant.sound();
		
	}

}
