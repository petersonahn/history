package exam2;

import java.util.Scanner;

public class Exam_08_02 {

	public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
		
		System.out.println("도형을 선택하세요.(1.원형, 2.사각형)");
		System.out.print("도형선택 >>> ");	
		
		int s = sc.nextInt();
		switch(s) {
		case 1:
			System.out.print("반지름 입력 >>> ");
			Shape circle = new Circle(sc.nextInt());
			System.out.println("====================");
			System.out.println("원의 면적 : " + circle.findArea());
			break;
		case 2:
			System.out.print("가로 >>> ");
			int width = sc.nextInt();			
			System.out.print("세로 >>> ");
			int height = sc.nextInt();
			Rectangle rectangle = new Rectangle(width, height);
			System.out.println("====================");
			System.out.println("사각형의 면적 : " + rectangle.findArea());
			break;
		default:
			System.out.println("1, 2 중에 선택해주세요");
			break;
		}
		
		sc.close();
	}

}
