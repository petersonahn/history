package exam2;

public class Circle implements Shape{

	int rad;
	
    public Circle() {}	
    
    public Circle(int rad) {
    	this.rad = rad;
    }

	@Override
	public double findArea() {	
		
		return 3.14 * rad * rad;		
		
	}

}
