package exam2;

public interface Shape {
	double findArea();
}
