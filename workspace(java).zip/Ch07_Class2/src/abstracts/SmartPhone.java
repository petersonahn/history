package abstracts;

public abstract class SmartPhone {
	String call = "전화";
	String sns = "문자";
	String search = "검색";
	String game = "게임";
	
	
	String company, name, color, size, weight, price;
	
	void purpose() {
		System.out.println
		("사용 목적 : " + call + " / " + sns + " / " + search + " / " + game);
	}
	
	abstract void spec();
	
}
