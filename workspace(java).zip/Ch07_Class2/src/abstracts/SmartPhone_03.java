package abstracts;

public class SmartPhone_03 {

	public static void main(String[] args) {
		Galaxy galaxy = new Galaxy();
		IPhone iphone = new IPhone();
		
		galaxy.purpose();
		galaxy.spec();
		
		System.out.println();
		
		iphone.purpose();
		iphone.spec();
		
	}

}
