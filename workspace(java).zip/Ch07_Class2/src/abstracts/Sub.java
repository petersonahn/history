package abstracts;

public class Sub extends Super{
	@Override
	void output() {
		System.out.println("");
	}
}
