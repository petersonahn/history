package abstracts;

public class Professor extends Student {
	public Professor() { }
	public Professor(String name, String major) {
		this.name = name;
		this.major = major;
	}
	
	
	@Override
	void getInfo() {
		System.out.println(name + "교수입니다.");
		System.out.println(major + "과목을 강의중입니다.");
	}
	
}
