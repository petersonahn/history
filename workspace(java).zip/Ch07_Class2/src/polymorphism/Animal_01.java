package polymorphism;

public class Animal_01 {

	public static void main(String[] args) {
		
		// 일반적으로 객체 생성 방법
		// Cat cat = new Cat();
		// cat.sound();
		
		// 다형성을 이용한 객체 생성 방법.
		Animal cat = new Cat();
		cat.sound();
		
		
		// 다형성을 이용하여 객체 생성 후에 자손 객체에
		// 접근 시 자손에서 만든 멤버에는 접근할 수 없음.
		// cat.output();
		
		// 자식 클래스에서 만든 메서드가 부모클래스에는
		// 존재하지 않기 때문에 다형성의 원칙에 맞지 않음.
		// Cat cat1 = new Animal();
		
		Tiger tiger = (Tiger)new Animal2();
		tiger.sound();
		/*
		 * 다운 캐스팅 : 조상타입의 참조변수를 자손타입의 참조변수로 변환하는 것.
		 * 업 캐스팅 : 자손타입의 참조변수를 조상타입의 참조변수로 변환하는 것.
		 */
	}

}
