package hi_class;

import java.util.Scanner;

/*
 * 2. 관계연산자(비교연산자)
 * 
 *  - >=(크거나 같은지)
 *  - >(큰지)
 *  - <=(작거나 같은지)
 *  - <(작은지)
 *  - == (같은지)
 *  - != (같지 않은지)
 *  
 *  - 결과값은 반드시 boolean 형으로 나옴 ==> true / false로 나옴.
 *  - 관계연산자는 제어문(조건문)에서 가장 많이 사용되는 연산자.
 *  
 */

public class Operator_05 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("첫번째 정수 입력 : ");
		int num1 = sc.nextInt();
		
		System.out.print("두번째 정수 입력 : ");
		int num2 = sc.nextInt();
		
		System.out.println("(num1 >= num2) 결과 >>> " + (num1 >= num2));
		System.out.println();
		
		System.out.println("(num1 > num2) 결과 >>> " + (num1 > num2));
		System.out.println();
		
		System.out.println("(num1 <= num2) 결과 >>> " + (num1 <= num2));
		System.out.println();
		
		System.out.println("(num1 < num2) 결과 >>> " + (num1 < num2));
		System.out.println();
		
		System.out.println("(num1 == num2) 결과 >>> " + (num1 == num2));
		System.out.println();
		
		System.out.println("(num1 != num2) 결과 >>> " + (num1 != num2));
		System.out.println();
		
		sc.close();
	}

}
