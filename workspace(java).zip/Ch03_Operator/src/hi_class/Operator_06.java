package hi_class;

import java.util.Scanner;

/*
 *  3. 논리연산자
 *  - 논리곱(&&) : 주어진 조건이 모두 참인 경우에만 결과가 true가 됨.
 *                그 나머지는 모두 false가 됨.
 *  - 논리합(||) : 주어진 조건 중에 어느 하나라도 참이면 결과는 true가 됨.
 *               모두 거짓일 경우에 false가 됨.
 *  - 부정(!) : true -> false, false -> true가 됨.
 *  
 *  - 관계연산자(비교연산자)의 결과값을 가지고 논리연산이 수행이 됨.
 */

public class Operator_06 {

	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
		
		System.out.print("첫번째 정수 입력 : ");
		int num1 = sc.nextInt();
		
		System.out.print("두번째 정수 입력 : ");
		int num2 = sc.nextInt();
		
		//논리곱인 경우
		boolean test = (num1 >= num2) && (num2 >= 5);
		System.out.println("test 결과 >>> " + test);
		
		test = (num1 >= num2) && (num2 <= 5);
		System.out.println("test 결과 >>> " + test);
		
		//논리합인 경우
		test = (num1 >= num2) || (num2 >= 5);
		System.out.println("test 결과 >>> " + test);
		
		
		sc.close();
	}

}
