package hi_class;

import java.util.Scanner;

public class Operator_04 {

	public static void main(String[] args) {
		// 키보드로 데이터를 입력받는 방법 - 세번째
		// System.in : 표준입력장치(키보드)
		Scanner sc = new Scanner(System.in);
		System.out.print("첫번째 정수 입력 : ");
		int su1 = sc.nextInt();
		System.out.print("두번째 정수 입력 : ");
		int su2 = sc.nextInt();
		
		System.out.println();
		System.out.println("첫번째 정수 : " + su1);
		System.out.println();
		
		System.out.println("두번째 정수 : " + su2);
		System.out.println();
		
		System.out.println("덧셈연산 결과 >>> " + (su1 + su2));
		System.out.println();
		
		System.out.println("뺄셈연산 결과 >>> " + (su1 - su2));
		System.out.println();
		
		System.out.println("곱셈연산 결과 >>> " + (su1 * su2));
		System.out.println();
		
		System.out.println("나눗셈연산 결과 >>> " + (su1 / su2));
		System.out.println();
		
		System.out.println("나머지연산 결과 >>> " + (su1 % su2));
		System.out.println();
		
		sc.close(); // scan 종료하는게 다른창과 데이터 겹치는 일이 발생하지 않아서 좋다.
	}

}
