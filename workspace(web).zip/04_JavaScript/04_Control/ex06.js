// while 반복문

let su = 1;

while(su <= 10) {
    console.log(`su >>> ${su++}`);
}