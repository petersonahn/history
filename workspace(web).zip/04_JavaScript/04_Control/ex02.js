// if~else문

let su = Number(prompt('정수 하나를 입력'));

if(su < 0) {
    alert('0 이상의 값을 입력하세요!!!');
} else {
    console.log(`입력한 숫자는 ${su} 입니다.`);
}