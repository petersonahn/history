let names = ['홍길동', '이순신', '유관순', '세종대왕', '신사임당'];

console.log(`${names}`);

// sort() : 배열의 요소를 정렬해 주는 함수 ==> 오름차순 정렬

names.sort();

console.log(`${names}`);

// reverse() : 배열의 요소를 정렬해 주는 함수 ==> 내림차순 정렬

names.reverse();

console.log(`${names}`);
