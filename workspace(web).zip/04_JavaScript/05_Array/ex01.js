/*
   자바스크립트에서 배열 생성 방법 - 3가지
   1. let 배열명 = new Array(원소1, 원소2, ...., 원소n);
   2. let 배열명 = [원소1, 원소2, ...., 원소n];
   3. let 배열명 = new Array();

   ※ 자바스크립트에서 배열은 모든 데이터 타입(자료형)의
       데이터를 다 담을 수 있음.
*/

// 1. let 배열명 = new Array(원소1, 원소2, ...., 원소n);
let arr1 = new Array('hong', 123, 3.14, true);

console.log(`${arr1}`);

console.log(`${arr1[3]}`);  // true

for(let i=0; i<arr1.length;i++){
    console.log(`arr1[${i}] >>> ${arr1[i]}`);
}

console.log(``);

// 자바스크립트에서 단축 for문, 개선된 for문

for(let k in arr1){
    console.log(`arr1 배열 요소 >>> ${arr1[k]}` );
}

console.log(``);

for(let k of arr1){
    console.log(`arr1 배열 요소 >>> ${k}` );
}

// 2. let 배열명 = [원소1, 원소2, ...., 원소n];


let arr2 = ['hong', 123, 3.14, true];

console.log(``);

for(let k of arr2){
    console.log(`arr2 배열 요소 >>> ${k}` );
}

// 3. let 배열명 = new Array();

let arr3 = new Array();

arr3[0] = 'hong';
arr3[1] = 123;
arr3[2] = 3.14;
arr3[3] = true;

console.log(``);

for(let k of arr3){
    console.log(`arr3 배열 요소 >>> ${k}` );
}

