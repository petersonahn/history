package com.test.java2;

public class TVUser {
	public static void main(String[] args) {
		
		// LgTV tv = new LgTV();
		
		// tv.turnOn();
		
		// tv.soundUp();
		
		// tv.soundDown();
		
		// tv.turnOff();
		
		TV tv = new LgTV();
		
		tv.powerOn();
		
		tv.volumeUp();
		
		tv.volumeDown();
		
		tv.powerOff();
		
		
	}
}
