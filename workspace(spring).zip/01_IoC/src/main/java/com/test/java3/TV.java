package com.test.java3;

public interface TV {

	void powerOn();

	void powerOff();

	void volumeUp();

	void volumeDown();

}