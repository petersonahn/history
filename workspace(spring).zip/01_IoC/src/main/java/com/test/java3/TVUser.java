package com.test.java3;

import org.springframework.context.support.GenericXmlApplicationContext;

public class TVUser {
	public static void main(String[] args) {
		
		// 컨테이너를 생성한다.
		// BeanContainer container = new BeanContainer();
		// 스프링에서 제공하는 컨테이너를 생성해야 함.
		GenericXmlApplicationContext container =
				new GenericXmlApplicationContext("applicationContext.xml");
		
		
		// 컨테이너로부터 객체를 검색(Lookup)한다.
		
		TV tv = (TV)container.getBean("tv");
		
		tv.powerOn();
		
		tv.volumeUp();
		
		tv.volumeDown();
		
		tv.powerOff();
		
		container.close();
		
	}
}
