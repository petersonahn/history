package com.spring.di03;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
public class Message {

	private String msg;
	
	
	// 비지니스 로직
	public void outputMsg() {
		
		System.out.println("메세지 >>> " + msg);
	}
	
}
