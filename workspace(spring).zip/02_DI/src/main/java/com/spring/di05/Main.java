package com.spring.di05;

import org.springframework.context.support.GenericXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		
		GenericXmlApplicationContext container = 
				new GenericXmlApplicationContext("player.xml", "team.xml");
		
		PlayerInfo info = container.getBean("info", PlayerInfo.class);
		
		info.getPlayerInfo();
		
		System.out.println();
		
		BaseballTeam team = (BaseballTeam)container.getBean("team");
		
		
		System.out.println("::: 국가대표 야구 선수단 :::");
		
		System.out.println("대표팀 감독 >>> " + team.getManager());
		
		System.out.println("대표팀 투수코치 >>> " + team.getBattingCoach());
		
		System.out.println("대표팀 타격코치 >>> " + team.getHittingCoach());
		
		System.out.println("대표팀 타자 >>> " + team.getHitter());
		
		System.out.println("태표팀 투수 >>> " + team.getPitcher());
		
		
		
		container.close();

	}

}
