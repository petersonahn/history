package com.spring.di01;

import org.springframework.context.support.GenericXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		
		// 스프링 컨테이너 객체 생성.
		GenericXmlApplicationContext container = 
					new GenericXmlApplicationContext("getsum.xml");
		
		// 스프링 컨테이너를 이용하여 빈을 가져오면 됨.
		GetSum sum = (GetSum)container.getBean("sum");
		
		sum.hap();   // 비지니스 메서드 호출.
		
		
		// 스프링 컨테이너를 사용하고 난 후에는 종료시키자.
		container.close();

	}

}
