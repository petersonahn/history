package com.spring.di;

public interface Speaker {

	void volumeUp();

	void volumeDown();

}