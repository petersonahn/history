package com.spring.di;

public class SamsungTV implements TV {
	
	private Speaker speaker;

	public SamsungTV() {
		System.out.println("==> SamsungTV 객체 생성(1)");
	}  // 기본 생성자
	
	public SamsungTV(Speaker speaker) {
		System.out.println("==> SamsungTV 객체 생성(2)");
		this.speaker = speaker;
	}  // 인자 생성자
	
	public void initMethod() {
		
		System.out.println("==> 멤버변수 초기화 메서드 호출");
		
	}
	
	public void powerOn() {
		System.out.println("SamsungTV --> 전원 켜기 ");
	}
	
	public void powerOff() {
		System.out.println("SamsungTV --> 전원 끄기");
	}
	
	public void volumeUp() {
		// System.out.println("SamsungTV --> 소리 올리기");
		speaker.volumeUp();
	}
	
	public void volumeDown() {
		// System.out.println("SamsungTV --> 소리 내리기");
		speaker.volumeDown();
	}
	
	
	
}
