package com.spring.di02;

import org.springframework.context.support.GenericXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		
		GenericXmlApplicationContext container = 
						new GenericXmlApplicationContext("hello.xml");
		
		MessageImpl message = (MessageImpl)container.getBean("msg");
		
		
		message.msg();
		
		
		container.close();

	}

}
