package com.mybatis.model;

import java.util.List;

public interface EmpDAO {
	
    List<Emp> getEmpList();
	
	int insertEmp(Emp dto);
	
	Emp getEmpCont(int empno);
	
	int updateEmp(Emp dto);
	
	int deleteEmp(int empno);
	
	void updateSequence(int empno);
}
