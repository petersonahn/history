package com.mybatis.emp;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mybatis.model.Emp;
import com.mybatis.model.EmpDAO;


@Controller
public class EmpController {
	
	@Autowired
	private EmpDAO dao;
	
	@RequestMapping("/")
	public String index() {
		
		return "main";
	}
	
	@RequestMapping("emp_list.go")
	public String list(Model model) {
		
		List<Emp> list = this.dao.getEmpList();
		
		model.addAttribute("List", list);
		
		
		return "emp_list";
		
	}
	
	@RequestMapping("emp_insert.go")
	public String insert(Model model) {
			
		return "emp_insert";
		
	}
	
	@RequestMapping("emp_insert_ok.go")
	public void insert_ok(Emp dto,
			HttpServletResponse response) throws IOException {
	
		int chk = this.dao.insertEmp(dto);
		
        response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter(); 
		
		if(chk > 0) {
			
			out.println("<script>");
			out.println("alert('사원 등록 성공!!!')");
			out.println("location.href='emp_list.go'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('사원 등록 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
}
