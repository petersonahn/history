package com.mybatis.product;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mybatis.model.Product;
import com.mybatis.model.ProductDAO;
import com.mybatis.model.Category;

@Controller
public class ProductController {
	
	@Autowired
	private ProductDAO dao;
	
	@RequestMapping("/")
	public String index() {
		
		return "main";
	}
	
	@RequestMapping("product_list.go")
	public String list(Model model) {
		
		List<Product> list = this.dao.getProductList();
		
		model.addAttribute("List", list);
		
		
		return "product_list";
		
	}
	
	@RequestMapping("product_insert.go")
	public String insert(Model model) {
	
		List<Category> cList = this.dao.getCategoryList();
		
		model.addAttribute("CategoryList", cList);
		
		return "product_insert";
		
	}	
	
	@RequestMapping("product_insert_ok.go")
	public void insert_ok(Product dto,
			HttpServletResponse response) throws IOException {
	
		int chk = this.dao.insertProduct(dto);
		
        response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter(); 
		
		if(chk > 0) {
			
			out.println("<script>");
			out.println("alert('제품 등록 성공!!!')");
			out.println("location.href='product_list.go'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('제품 등록 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
	@RequestMapping("product_content.go")
	public String cont(@RequestParam("pnum") int pnum, Model model) {
		
		Product content = this.dao.getProductCont(pnum);
		
		model.addAttribute("Cont", content);
		
		
		return "product_content";
		
	}
	
	@RequestMapping("product_modify.go")
	public String modify(@RequestParam("pnum") int pnum,
			                      Model model) {
		Product content = this.dao.getProductCont(pnum);
		
		model.addAttribute("Modify", content);
		
		return "product_modify";
		
	}
	
	@RequestMapping("product_modify_ok.go")
	public void modify_ok(Product dto,
			HttpServletResponse response) throws IOException {
		
		int check = this.dao.updateProduct(dto);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			out.println("<script>");
			out.println("alert('제품 정보 수정 성공!!!')");
			out.println("location.href='product_content.go?pnum="+dto.getPnum()+"'");
			out.println("</script>");
		} else {
			out.println("<script>");
			out.println("alert('제품 정보 수정 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
	@RequestMapping("product_delete.go")
	public void delete_ok(@RequestParam("pnum") int pnum,
			    Model model,
				HttpServletResponse response) throws IOException {
		
		model.addAttribute("pnum", pnum);
		
		int check = this.dao.deleteProduct(pnum);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			
			this.dao.updateSequence(pnum);
			
			out.println("<script>");
			out.println("alert('제품 삭제 성공!!!')");
			out.println("location.href='product_list.go'");
			out.println("</script>");
			
		}else {
			out.println("<script>");
			out.println("alert('제품 삭제 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
}
