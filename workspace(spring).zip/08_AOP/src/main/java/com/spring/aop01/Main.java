package com.spring.aop01;

import org.springframework.context.support.GenericXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		
		GenericXmlApplicationContext container =
				new GenericXmlApplicationContext("aop01.xml");
		
		Person boy = (Person)container.getBean("boy");
		
		boy.doSomething();
		
		System.out.println(":::::::::::::::::::::::::::::::::");
		
        Person girl = (Person)container.getBean("girl");
		
		girl.doSomething();
		
		container.close();

	}

}
