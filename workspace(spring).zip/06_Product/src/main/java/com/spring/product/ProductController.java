package com.spring.product;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.spring.model.Category;
import com.spring.model.Product;
import com.spring.model.ProductService;

@Controller
public class ProductController {
	
	@Autowired
	private ProductService service;
	
	@RequestMapping("product_list.go")
	public String list(Model model) {
		
		// 제품 전체 리스트 조회하는 메서드 호출.
		List<Product> list = this.service.getList();
		
		model.addAttribute("List", list);
		
		return "product_list";
	}
	
	@RequestMapping("product_insert.go")
	public String insert(Model model) {
	
		List<Category> cList = this.service.categoryList();
		
		model.addAttribute("CategoryList", cList);
		
		return "product_insert";
		
	}	
	
	@RequestMapping("product_insert_ok.go")
	public void insert_ok(Product dto,
			HttpServletResponse response) throws IOException {
	
		int chk = this.service.insert(dto);
		
        response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter(); 
		
		if(chk > 0) {
			
			out.println("<script>");
			out.println("alert('제품 등록 성공!!!')");
			out.println("location.href='product_list.go'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('제품 등록 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
	@RequestMapping("product_content.go")
	public String cont(@RequestParam("pnum") int pnum,
							Model model) {
		
		Product cont = this.service.content(pnum);
		
		model.addAttribute("Content", cont);
		
		
		return "product_content";
		
	}
		
	@RequestMapping("product_modify.go")
	public String modify(@RequestParam("pnum") int pnum,
							Model model) {
		
		Product cont = this.service.content(pnum);
		
		model.addAttribute("Modify", cont);
		
		
		return "product_modify";
		
	}
	
	@RequestMapping("product_modify_ok.go")
	public void modify_ok(Product dto,
			HttpServletResponse response) throws IOException {
		
		int check = this.service.update(dto);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			out.println("<script>");
			out.println("alert('제품 정보 수정 성공!!!')");
			out.println("location.href='product_content.go?pnum="+dto.getPnum()+"'");
			out.println("</script>");
		} else {
			out.println("<script>");
			out.println("alert('제품 정보 수정 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	

	
	
	@RequestMapping("product_delete.go")
	public void delete_ok(@RequestParam("pnum") int pnum,
			    Model model,
				HttpServletResponse response) throws IOException {
		
		model.addAttribute("pnum", pnum);
		
		int check = this.service.delete(pnum);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			// 회원 삭제 후 회원번호 재작업 메서드 호출.
			this.service.sequence(pnum);
			
			out.println("<script>");
			out.println("alert('제품 삭제 성공!!!')");
			out.println("location.href='product_list.go'");
			out.println("</script>");
			
		}else {
			out.println("<script>");
			out.println("alert('제품 삭제 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}	
	
}
