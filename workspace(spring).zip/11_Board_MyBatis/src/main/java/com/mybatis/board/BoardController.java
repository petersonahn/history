package com.mybatis.board;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mybatis.model.BoardDAO;
import com.mybatis.model.Page;
import com.mybatis.model.Board;

@Controller
public class BoardController {
	
	@Autowired
	private BoardDAO dao;
	
	private final int rowsize = 3;
	
	private int totalRecord = 0;
	
	@RequestMapping("/")
	public String home() {
		
		return "main";
		
	}
	
	@RequestMapping("board_list.go")
	public String list(HttpServletRequest request,
			Model model) {
		
		int page;
		
		if(request.getParameter("page") != null) {
			
			page = Integer.parseInt(request.getParameter("page"));
			
		} else {
			
			page = 1;
			
		}
		
		totalRecord = this.dao.getListCount();
		
		Page pdto = new Page(page, rowsize, totalRecord);
		
		List<Board> list = this.dao.getBoardList(pdto);
		
		model.addAttribute("List", list)
		     .addAttribute("Page", pdto);
		
		
		return "board_list";
		
	}
	
	@RequestMapping("board_write.go")
	public String write() {
		
		return "board_write";
		
	}
	
	@RequestMapping("board_write_ok.go")
	public void insert_ok(Board dto,
			HttpServletResponse response) throws IOException {
		
		int chk = this.dao.insertBoard(dto);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(chk > 0) {
			
			out.println("<script>");
			out.println("alert('게시글 등록 성공!!!')");
			out.println("location.href='board_list.go'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('게시글 등록 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
				
	}
	
	@RequestMapping("board_content.go")
	public String cont(@RequestParam("no") int no,
							Model model) {		
		
		this.dao.readCount(no);
		
		Board cont = this.dao.boardContent(no);
				
		
		model.addAttribute("Content", cont);
		
		
		return "board_content";
		
	}
	
	@RequestMapping("board_modify.go")
	public String modify(@RequestParam("no") int no,
							Model model) {
		
		Board cont = this.dao.boardContent(no);
		
		model.addAttribute("Modify", cont);
		
		
		return "board_modify";
		
	}
	
	@RequestMapping("board_modify_ok.go")
	public void modify_ok(Board dto, Page pdto,
			@RequestParam("db_pwd") String db_pwd,
			HttpServletResponse response) throws IOException {
			
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(db_pwd.equals(dto.getBoard_pwd())) {
			
			int chk = this.dao.updateBoard(dto);
			
			if(chk > 0) {
				out.println("<script>");
				out.println("alert('회원 정보 수정 성공!!!')");
				out.println("location.href='board_content.go?no="+dto.getBoard_no()+"&page="+ pdto.getPage() +"'");
				out.println("</script>");
			}else {
				out.println("<script>");
				out.println("alert('회원 정보 수정 실패.~~~')");
				out.println("history.back()");
				out.println("</script>");
			}
		
		}else {
			// 비밀번호가 틀린 경우
			out.println("<script>");
			out.println("alert('비밀번호가 틀립니다. 확인해 주세요.~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
	}
	
	@RequestMapping("board_delete.go")
	public String delete(@RequestParam("no") int no,
							Model model) {
		
		model.addAttribute("no", no);
		
		return "board_delete";
		
	}
	
	
	@RequestMapping("board_delete_ok.go")
	public void delete_ok(@RequestParam("no") int no,
				@RequestParam("pwd") String pwd,
				HttpServletResponse response) throws IOException {
		
		Board cont = this.dao.boardContent(no);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(pwd.equals(cont.getBoard_pwd())) {
			
			int check = this.dao.deleteBoard(no);
			
			if(check > 0) {
				// 회원 삭제 후 회원번호 재작업 메서드 호출.
				this.dao.updateSequence(no);
				
				out.println("<script>");
				out.println("alert('게시글 삭제 성공!!!')");
				out.println("location.href='board_list.go'");
				out.println("</script>");
				
			}else {
				out.println("<script>");
				out.println("alert('게시글 삭제 실패~~~')");
				out.println("history.back()");
				out.println("</script>");
			}
			
		}else {
			// 비밀번호가 틀린 경우
			out.println("<script>");
			out.println("alert('비밀번호가 틀리네요. 확인해 주삼~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
	@RequestMapping("board_search.go")
	public String search(@RequestParam("field") String field,
			@RequestParam("keyword") String keyword,
			HttpServletRequest request, Model model) {
		
        int page;
		
		if(request.getParameter("page") != null) {
			
			page = Integer.parseInt(request.getParameter("page"));
			
		} else {
			
			page = 1;
			
		}
		
		Map<String, String> map = 
				new HashMap<String, String>();
		
		map.put("Field", field);
		map.put("Keyword", keyword);
		
		totalRecord = this.dao.searchBoardCount(map);
		
		Page pDto = new Page(page, rowsize, totalRecord, field, keyword);
		
		List<Board> searchList = this.dao.searchBoardList(pDto);
		
		model.addAttribute("searchPageList", searchList)
	         .addAttribute("Paging", pDto);
	
	
	    return "board_search";
	}
	
}
