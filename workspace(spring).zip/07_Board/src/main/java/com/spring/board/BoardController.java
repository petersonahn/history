package com.spring.board;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.spring.model.Board;
import com.spring.model.BoardDAOImpl;
import com.spring.model.BoardService;


@Controller
public class BoardController {
	@Autowired
	private BoardService service;
	
	@RequestMapping("board_list.go")
	public String list(Model model) {
		
		List<Board> boardList = this.service.getList();
		
		model.addAttribute("BoardList", boardList);
		
		
		return "board_list";
		
	}
	
	@RequestMapping("board_write.go")
    public String insert() {
		
		return "board_write";
		
	}
	
	@RequestMapping("board_write_ok.go")
	public void insert_ok(Board dto,
			HttpServletResponse response) throws IOException {
		
		int chk = this.service.insert(dto);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(chk > 0) {
			
			out.println("<script>");
			out.println("alert('게시글 등록 성공!!!')");
			out.println("location.href='board_list.go'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('게시글 등록 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
				
	}
	
	@RequestMapping("board_content.go")
	public String cont(@RequestParam("no") int no,
							Model model) {		
		
		this.service.readCount(no);
		
		Board cont = this.service.content(no);
				
		
		model.addAttribute("Content", cont);
		
		
		return "board_content";
		
	}
	
	@RequestMapping("board_modify.go")
	public String modify(@RequestParam("no") int no,
							Model model) {
		
		Board cont = this.service.content(no);
		
		model.addAttribute("Modify", cont);
		
		
		return "board_modify";
		
	}
	
	@RequestMapping("board_modify_ok.go")
	public void modify_ok(Board dto,
			HttpServletResponse response) throws IOException {
		
		int check = this.service.update(dto);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			out.println("<script>");
			out.println("alert('게시글 정보 수정 성공!!!')");
			out.println("location.href='board_content.go?no="+dto.getBoard_no()+"'");
			out.println("</script>");
		}else if(check == -1) {
			out.println("<script>");
			out.println("alert('비밀번호가 틀리네요. 확인해 주세요~~~')");
			out.println("history.back()");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('게시글 정보 수정 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
	@RequestMapping("board_delete.go")
	public String delete(@RequestParam("no") int no,
							Model model) {
		
		model.addAttribute("no", no);
		
		return "board_delete";
		
	}
	
	
	@RequestMapping("board_delete_ok.go")
	public void delete_ok(@RequestParam("no") int no,
				@RequestParam("pwd") String pwd,
				HttpServletResponse response) throws IOException {
		
		Board cont = this.service.content(no);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(pwd.equals(cont.getBoard_pwd())) {
			
			int check = this.service.delete(no);
			
			if(check > 0) {
				// 회원 삭제 후 회원번호 재작업 메서드 호출.
				this.service.sequence(no);
				
				out.println("<script>");
				out.println("alert('게시글 삭제 성공!!!')");
				out.println("location.href='board_list.go'");
				out.println("</script>");
				
			}else {
				out.println("<script>");
				out.println("alert('게시글 삭제 실패~~~')");
				out.println("history.back()");
				out.println("</script>");
			}
			
		}else {
			// 비밀번호가 틀린 경우
			out.println("<script>");
			out.println("alert('비밀번호가 틀리네요. 확인해 주삼~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
}
