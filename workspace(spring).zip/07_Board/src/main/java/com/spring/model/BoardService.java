package com.spring.model;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BoardService {
	
	@Autowired
	private BoardDAO dao;
	
	public List<Board> getList() {
		return this.dao.getBoardList();
	}
	
	public int insert(Board dto) {
		return this.dao.insertBoard(dto);
	}
	
	public Board content(int board_no) {
		return this.dao.getBoardCont(board_no);
	}
	
	public int update(Board dto) {
		return this.dao.updateBoard(dto);
	}
	
	public int delete(int board_no) {
		return this.dao.deleteBoard(board_no);
	}
	
	public void sequence(int board_no) {
		this.dao.updateSequence(board_no);
	}

	public void readCount(int no) {
		
		this.dao.readCount(no);
		
	}
}
