package com.reply.action;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.reply.model.BbsDAO;
import com.reply.model.BbsDTO;

public class BbsReplyAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		
		// get 방식으로 넘어온 글번호에 해당하는 게시글을
		// jsp_bbs 테이블에서 조회하여 해당 게시글을
		// 답변 글 폼 페이지(view page)로 이동시키는 비지니스 로직.
		
		int bbs_no = 
				Integer.parseInt(request.getParameter("no"));
		
        BbsDAO dao = BbsDAO.getInstance();
		
		BbsDTO content = dao.getBbsContent(bbs_no);
		
		request.setAttribute("Reply", content);

        ActionForward forward = new ActionForward();
		
		forward.setRedirect(false);
		
		forward.setPath("bbs_reply.jsp");
		
		return forward;
	}

}
