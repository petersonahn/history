package com.reply.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.reply.model.BbsDAO;

public class BbsDeleteOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws IOException {

        String board_pwd = request.getParameter("pwd").trim();
		
		int board_no = 
				Integer.parseInt(request.getParameter("bbs_no"));
				
		
		BbsDAO dao = BbsDAO.getInstance();
		
		int chk = dao.deleteBbs(board_no, board_pwd);
		
		PrintWriter out = response.getWriter();
		
		if(chk > 0) {			
			// 원글이 삭제된 경우
			out.println("<script>");
			out.println("alert('게시글 원글이 삭제되었습니다!!!')");
			out.println("location.href='bbs_list.go'");
			out.println("</script>");
			
		}else if(chk == -2) {
			// 답변글이 삭제된 경우
			out.println("<script>");
			out.println("alert('게시글 댓글이 삭제되었습니다!!!')");
			out.println("location.href='bbs_list.go'");
			out.println("</script>");
			
		}else if(chk == -1) {
			
			out.println("<script>");
			out.println("alert('비밀번호가 틀립니다. 확인 요망~~~')");
			out.println("history.back()");
			out.println("</script>");
			
		}else {
			
			out.println("<script>");
			out.println("alert('게시글 삭제 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		return null;
	}

}
