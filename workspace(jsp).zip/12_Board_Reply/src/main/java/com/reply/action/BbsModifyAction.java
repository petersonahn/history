package com.reply.action;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.reply.model.BbsDAO;
import com.reply.model.BbsDTO;

public class BbsModifyAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		
		int bbs_no =
				Integer.parseInt(request.getParameter("no"));
		
        BbsDAO dao = BbsDAO.getInstance();
		
		BbsDTO content = dao.getBbsContent(bbs_no);
		
		request.setAttribute("Modify", content);

        ActionForward forward = new ActionForward();
		
		forward.setRedirect(false);
		
		forward.setPath("bbs_modify.jsp");
		
		return forward;
	}

}
