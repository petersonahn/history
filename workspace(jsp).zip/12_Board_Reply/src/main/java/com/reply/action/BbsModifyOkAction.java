package com.reply.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.reply.model.BbsDAO;
import com.reply.model.BbsDTO;


public class BbsModifyOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String board_writer = request.getParameter("writer").trim();
		String board_title = request.getParameter("title").trim();
		String board_cont = request.getParameter("cont").trim();
		String board_pwd = request.getParameter("pwd").trim();
		
		// type="hidden"으로 넘어온 데이터들도 받아주어야 한다.
		int board_no = 
				Integer.parseInt(request.getParameter("board_no"));
		
		String db_pwd = request.getParameter("db_pwd");		
		
		BbsDTO dto = new BbsDTO();
		
		dto.setBoard_no(board_no);
		dto.setBoard_writer(board_writer);
		dto.setBoard_title(board_title);
		dto.setBoard_cont(board_cont);
		dto.setBoard_pwd(board_pwd);
		
		BbsDAO dao = BbsDAO.getInstance();
		
		PrintWriter out = response.getWriter();
		
		if(board_pwd.equals(db_pwd)) {
			
			int chk = dao.updateBbs(dto);
			
			if(chk > 0) {
				out.println("<script>");
				out.println("alert('게시글 수정 성공!!!')");
				out.println("location.href='bbs_content.go?no="+dto.getBoard_no()+"'");
				out.println("</script>");
			}else {
				out.println("<script>");
				out.println("alert('게시글 수정 실패~~~')");
				out.println("history.back()");
				out.println("</script>");
			}
		
		}else {
			// 비밀번호가 틀리다면
			out.println("<script>");
			out.println("alert('비밀번호가 틀립니다. 다시 입력해주세요~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
				
		return null;
	}

}
