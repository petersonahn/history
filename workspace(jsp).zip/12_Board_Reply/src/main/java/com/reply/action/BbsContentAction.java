package com.reply.action;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.reply.model.BbsDAO;
import com.reply.model.BbsDTO;

public class BbsContentAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		
		int bbs_no = 
				Integer.parseInt(request.getParameter("no"));
		
        BbsDAO dao = BbsDAO.getInstance();
		
		// 글제목을 클릭 시 조회수를 증가시켜 주는 메서드 호출.
		dao.bbsReadCount(bbs_no);
		
		// 글번호에 해당하는 게시글의 상세 정보를 조회하는 메서드 호출.
		BbsDTO content = dao.getBbsContent(bbs_no);
		
		request.setAttribute("Cont", content);
		
        ActionForward forward = new ActionForward();
		
		forward.setRedirect(false);
		
		forward.setPath("bbs_content.jsp");
		
		return forward;
	}

}
