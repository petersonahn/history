package com.himedia;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/score")
public class ScoreServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public ScoreServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// method="post" 방식인 경우
		// 요청 데이터에 한글이 있으면 한글이 깨지는 현상이 발생함. - 톰캣이 8버전 이하.
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
				
		String score_name = request.getParameter("name").trim();
		int score_kor = Integer.parseInt(request.getParameter("kor").trim());
		int score_eng = Integer.parseInt(request.getParameter("eng").trim());
		int score_math = Integer.parseInt(request.getParameter("math").trim());
		int score_sum = score_kor + score_eng + score_math;
		double score_avg = score_sum / 3.0;
		String score_grade = ""; 
		if (score_avg >= 90) {
			score_grade = "A";		
		} else if(score_avg >= 80) {
			score_grade = "B";		
		} else if(score_avg >= 70) {
			score_grade = "C";		
		}else if(score_avg >= 60) {
			score_grade = "D";		
		}else {
			score_grade = "F";		
		};
		
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<head></head>");
		out.println("<body>");
		out.println("<h2>이 름 : " + score_name + "<br>");
		out.println("국어점수 : " + score_kor + "점<br>");
		out.println("영어점수 : " + score_eng + "점<br>");
		out.println("수학점수 : " + score_math + "점<br>");
		out.println("총 점 : " + score_sum + "점<br>");
		out.printf("평 균 : %.2f점", score_avg);
		out.println("<br>");
		out.println("학 점 : " + score_grade + "학점</h2>");
		out.println("</body>");
		out.println("</html>");
	}

}
