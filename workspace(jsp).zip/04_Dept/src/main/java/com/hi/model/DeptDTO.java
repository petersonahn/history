package com.hi.model;

// 데이터베이스의 데이터를 전송하는 객체
// 1. 데이터를 추가
//    입력폼 -> DB 저장

// 2. 데이터를 조회
//    DB -> 웹 브라우저

public class DeptDTO {

	private int deptno;
	private String dname;
	private String loc;
	
	
	public int getDeptno() {
		return deptno;
	}
	
	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}
	
	public String getDname() {
		return dname;
	}
	
	public void setDname(String dname) {
		this.dname = dname;
	}
	
	public String getLoc() {
		return loc;
	}
	
	public void setLoc(String loc) {
		this.loc = loc;
	}
	
	
}
