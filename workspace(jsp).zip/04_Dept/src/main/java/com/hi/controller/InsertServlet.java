package com.hi.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hi.model.DeptDAO;
import com.hi.model.DeptDTO;


@WebServlet("/insertOk")
public class InsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public InsertServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// insert.jsp 페이지에서 넘어온 데이터들을
		// dept 테이블에 저장시키는 비지니스 로직.
		
		// 한글 인코딩 작업 진행
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		// 1단계 : 부서 등록 폼 페이지에서 넘어온 데이터들을 받아주어야 한다.
		int deptno = Integer.parseInt(request.getParameter("deptno").trim());
		
		String deptName = request.getParameter("deptname").trim();
		
		String location = request.getParameter("location").trim();
		
		// 2단계 : DB에 전송할 DTO 객체 생성.
		DeptDTO dto = new DeptDTO();
		
		dto.setDeptno(deptno);
		dto.setDname(deptName);
		dto.setLoc(location);
		
		// 3단계 : 실제로 DB에 DTO 객체를 전송.
		DeptDAO dao = new DeptDAO();
		
		int res = dao.insertDept(dto);
		
		System.out.println("res >>> " + res);
		
		PrintWriter out = response.getWriter();
		
		if(res > 0) {
			// 부서 등록 추가가 성공한 경우
			out.println("<script>");
			out.println("alert('부서 추가 등록 성공했습니다.!!!')");
			out.println("location.href='select'");
			out.println("</script>");
		}else {
			// 부서 등록 추가가 실패한 경우
			out.println("<script>");
			out.println("alert('부서 추가 등록 실패.~~~')");
			out.println("history.back()");  // 이전 페이지로 이동
			out.println("</script>");
		}
	}

}
