package com.board.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.board.model.BoardDAO;
import com.board.model.BoardDTO;


@WebServlet("/search.go")
public class SearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public SearchServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 검색 폼 창에서 넘어온 검색어를 가지고 BOARD 테이블에서
		// 검색어에 해당하는 모든 게시물을 view page로 이동시키는 비지니스 로직.
		
		request.setCharacterEncoding("UTF-8");
		
		response.setContentType("text/html; charset=UTF-8");
		
		String find_field = request.getParameter("find_field").trim();
		
		String find_keyword = request.getParameter("find_keyword").trim();
		
		BoardDAO dao = BoardDAO.getInstance();
		
		List<BoardDTO> searchList =
				dao.searchBoardList(find_field, find_keyword);
		
		request.setAttribute("Search", searchList);
		
		request.getRequestDispatcher("board_searchList.jsp")
		           .forward(request, response);
		
	}

}
