package com.reply2.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.reply2.model.TblDAO;
import com.reply2.model.TblDTO;

public class TblWriteOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String tbl_writer = request.getParameter("writer").trim();
		
		String tbl_title = request.getParameter("title").trim();
		
		String tbl_cont = request.getParameter("content").trim();
		
		String tbl_pwd = request.getParameter("pwd").trim();
		
		
	    TblDTO dto = new TblDTO();
		
		dto.setWriter(tbl_writer);
		dto.setTitle(tbl_title);
		dto.setContent(tbl_cont);
		dto.setPwd(tbl_pwd);
		
		TblDAO dao = TblDAO.getInstance();
		
		int chk = dao.insertTbl(dto);
		
		PrintWriter out = response.getWriter();
		
		if(chk > 0) {
			out.println("<script>");
			out.println("alert('게시글 추가 성공!!!')");
			out.println("location.href='tbl_list.go'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('게시글 추가 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		return null;
	}

}
