package com.member.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;


public class MemberDAO {

	// 멤버변수
	// 1. DB와 연동하는 객체.
	Connection con = null;
	
	// 2. DB에 SQL문을 전송하는 객체.
	PreparedStatement pstmt = null;
	
	// 3. SQL문을 실행한 후에 결과값을 가지고 있는 객체.
	ResultSet rs = null;
	
	// 4. SQL 문을 저장할 문자열 객체.
	String sql = null;
	
	
	// MemberDAO 객체를 싱글톤 방식으로 만들어 보자.
	// 1단계 : 싱글톤 방식으로 객체를 만들기 위해서는 우선적으로
	//        기본 생성자의 접근제한을 private으로 선언해야 함.
	
	// 2단계 : MemberDAO 객체를 정적 멤버로 선언해야 함. - static으로 선언해야 함.
	private static MemberDAO instance = null;
	
	private MemberDAO() { }  // 기본 생성자
	
	// 3단계 : 기본 생성자 대신에 싱글턴 객체를 return 해 주는
	//        getInstance() 라는 메서드를 만들어서 외부에서는
	//        해당 메서드로 접근할 수 있게 해 주면 됨.
	public static MemberDAO getInstance() {
		
		if(instance == null) {
			instance = new MemberDAO();
		}
		
		return instance;
		
	}  // getInstance() 메서드 end
	
	
	
	// DB와 연동하는 작업을 하는 메서드. - DBCP 방식으로 연결 진행.
	public void openConn() {
		
		
		try {
			// 1단계 : JNDI 서버 객체 생성.
			Context ctx = new InitialContext();
			
			// 2단계 : lookup() 메서드를 이용하여 매칭되는 커넥션을 찾는다.
			DataSource ds = 
					(DataSource)ctx.lookup("java:comp/env/jdbc/myoracle");
			// 3단계 : DataSource 객체를 이용하여 커넥션 객체를 하나 가져온다.
			con = ds.getConnection();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}  // openConn() 메서드 end
	
	
	// 자원을 종료시키는 메서드.
	public void closeConn(ResultSet rs, 
				PreparedStatement pstmt, Connection con) {
		
		try {
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			if(con != null) con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}  // closeConn(rs, pstmt, con) 메서드 end
	
	
	// 자원을 종료시키는 메서드.
	public void closeConn(PreparedStatement pstmt, 
					Connection con) {
		
		try {
			if(pstmt != null) pstmt.close();
			if(con != null) con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}  // closeConn(pstmt, con) 메서드 end
	
	public int checkMemberId(String id) {
		
		int result = 0;
			
		
		try {
			openConn();
			
			sql = "select* from member where memid = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, id);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				result = -1;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		}
		
		return result;
				
	} // checkMemberId() 메서드 end
	
	public String getCustomerList() {
		
		String result="";		
		
		try {
			openConn();
			
			sql = "select * from customer order by num desc";
			
			pstmt = con.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			result += "<customers>";
			
			while(rs.next()) {
				
				result += "<customer>";
				
				result += "<num>" + rs.getInt("num") + "</num>";
				
				result += "<id>" + rs.getString("id") + "</id>";
				
				result += "<name>" + rs.getString("name") + "</name>";
				
				result += "<age>" + rs.getInt("age") + "</age>";
				
				result += "<phone>" + rs.getString("phone") + "</phone>";
				
				result += "<addr>" + rs.getString("addr") + "</addr>";
				
				result += "</customer>";
				
			}
			
			result += "</customers>";
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(rs, pstmt, con);
			
		}
		
		
		return result;
	} // getCustomerList() 메서드 end
	
	public String idCheck(String id) {
		
		String result = "사용가능한 아이디입니다.";
		
		
		try {
			
			openConn();
			
			sql = "select * from customer where id = ?";			
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, id);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				// 입력한 아이디가 중복인 경우 - 테이블에 존재하는 경우
				result = "중복 아이디입니다.";
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		}
						
		return result;
		
	} // idCheck() 메서드 end

	public int insertCustomer(CustDTO dto) {
		
		int result = 0, count = 0;		
		
		try {
			
			openConn();
			
			sql = "select count(num) from customer";
			
			pstmt = con.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				
				count = rs.getInt(1);
				
			}
			
			sql = "insert into customer values(?, ?, ?, ?, ?, ?)";
			
            pstmt = con.prepareStatement(sql);
            
            pstmt.setInt(1, count + 1);            
            pstmt.setString(2, dto.getId());
            pstmt.setString(3, dto.getName());
            pstmt.setInt(4, dto.getAge());
            pstmt.setString(5, dto.getPhone());
            pstmt.setString(6, dto.getAddr());
			
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			closeConn(rs, pstmt, con);
		}
		
		return result;
	} // insertCustomer() 메서드 end

	public int deleteCustomer(int no) {
		
		int result = 0;		
		
		try {
			openConn();
			
			sql = "delete from customer where num = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, no);
			
			result = pstmt.executeUpdate();
			
			if(result > 0) {
				sql = "update customer set num = num - 1 where num > ?";
				
				pstmt = con.prepareStatement(sql);
				
				pstmt.setInt(1, no);
				
				result = pstmt.executeUpdate();
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			closeConn(pstmt, con);
		}
		
		return result;
		
	} // deleteCustomer() 메서드 end
	
	
	
}








