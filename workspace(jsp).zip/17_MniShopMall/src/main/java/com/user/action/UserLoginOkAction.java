package com.user.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.shop.controller.Action;
import com.shop.controller.ActionForward;

import com.shop.model.MemberDTO;
import com.shop.model.UserDAO;


public class UserLoginOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws IOException {


        String user_id = request.getParameter("user_id").trim();
		
		String user_pwd = request.getParameter("user_pwd").trim();
		
		UserDAO dao = UserDAO.getInstance();
		
		int chk = dao.userCheck(user_id, user_pwd);
		
		ActionForward forward = new ActionForward();
		
		PrintWriter out = response.getWriter();
		       
		
		if(chk > 0) {
			// 아이디와 비밀번호가 일치하는 사용자
			// 사용자인 경우 사용자의 정보를 받아와 보자.
			MemberDTO cont = dao.getMember(user_id);
			
			HttpSession session = request.getSession();
			
			// 사용자의 정보를 세션에 저장을 하여 앞으로 사용을 하자.
			session.setAttribute("UserId", cont.getMemid());
			session.setAttribute("UserName", cont.getMemname());
			
			// 세션에 저장된 정보를 가지고 view page(사용자 메인 페이지)로 이동을 하자.
			forward.setRedirect(true);
			
			forward.setPath("user_main.go");
			
		}else if(chk == -1) {
			// 아이디는 일치하나 비밀번호가 틀린 경우
			out.println("<script>");
			out.println("alert('사용자 비밀번호가 틀립니다. 확인 요망~~~')");
			out.println("history.back()");
			out.println("</script>");
		}else {
			// 회원이 아닌 경우.
			out.println("<script>");
			out.println("alert('존재하지 않는 사용자 아이디입니다.~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		return forward;
	}	
	
}
