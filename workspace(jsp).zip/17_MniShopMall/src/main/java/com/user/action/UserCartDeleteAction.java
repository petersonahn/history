package com.user.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shop.controller.Action;
import com.shop.controller.ActionForward;
import com.shop.model.CartDAO;

public class UserCartDeleteAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		
		int cart_no =
				Integer.parseInt(request.getParameter("num"));
		
		CartDAO dao = CartDAO.getInstance();
		
		int chk = dao.deleteCart(cart_no);
		
		PrintWriter out = response.getWriter();
		
        if(chk >= 0) {
			
			out.println("<script>");
			out.println("alert('장바구니 제품 삭제 성공!!!')");
			out.println("location.href='user_cart_list.go'");
			out.println("</script>");
		}else {
			
			out.println("<script>");
			out.println("alert('장바구니 제품 삭제 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		return null;
	}

}
