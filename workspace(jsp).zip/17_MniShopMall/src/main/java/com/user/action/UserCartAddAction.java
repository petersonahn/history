package com.user.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.shop.controller.Action;
import com.shop.controller.ActionForward;
import com.shop.model.CartDAO;
import com.shop.model.CartDTO;


public class UserCartAddAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		
		String product_name = request.getParameter("p_name").trim();
		
		int product_price = 
				Integer.parseInt(request.getParameter("p_price").trim());
		
		int product_pqty = 
				Integer.parseInt(request.getParameter("p_qty").trim());
		
		int product_num = 
				Integer.parseInt(request.getParameter("p_num"));
		
		String product_pspec = request.getParameter("p_spec");
		
		String product_pimage = request.getParameter("p_image");
		
		String user_id = request.getParameter("userId");
		
		CartDTO dto = new CartDTO();
		
		dto.setCart_pnum(product_num);
		dto.setCart_userid(user_id);
		dto.setCart_pname(product_name);
		dto.setCart_pqty(product_pqty);
		dto.setCart_price(product_price);
		dto.setCart_pspec(product_pspec);
		dto.setCart_pimage(product_pimage);
		
		CartDAO dao = CartDAO.getInstance();
		
		int chk = dao.insertCart(dto);
				
		PrintWriter out = response.getWriter();
		       
		
		if(chk > 0) {
			
			out.println("<script>");
			out.println("alert('장바구니에 제품 저장 성공!!!')");
			out.println("location.href='user_cart_list.go'");
			out.println("</script>");
			
		} else {
			
			out.println("<script>");
			out.println("alert('장바구니에 제품 저장 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		return null;
	}

}
