package com.emp.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.emp.model.EmpDAO;
import com.emp.model.EmpDTO;


@WebServlet("/modify_ok.go")
public class ModifyOkServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public ModifyOkServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 수정 폼 페이지에서 넘어온 데이터들을 받아서
		// EMP 테이블에서 사원번호에 해당하는 사원의 
		// 정보를 수정하는 비지니스 로직.
		
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		String re_empno = request.getParameter("num").trim();
		
		String re_name = request.getParameter("name").trim();
		
		String re_job = request.getParameter("job").trim();
		
		String re_mgr = request.getParameter("mgr").trim();
		
		String re_sal = request.getParameter("sal").trim();
		
		String re_comm = request.getParameter("comm").trim();
		
		String re_deptno = request.getParameter("deptno").trim();
		
		
		EmpDTO dto = new EmpDTO();
		
		dto.setEmpno(Integer.parseInt(re_empno));
		dto.setEname(re_name);
		dto.setJob(re_job);
		dto.setMgr(Integer.parseInt(re_mgr));
		dto.setSal(Integer.parseInt(re_sal));
		dto.setComm(Integer.parseInt(re_comm));
		dto.setDeptno(Integer.parseInt(re_deptno));
		
		
		EmpDAO dao = EmpDAO.getInstance();
		
		int check = dao.modifyEmp(dto);
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			out.println("<script>");
			out.println("alert('사원 정보 수정 성공!!!')");
			out.println("location.href='content.go?no="+dto.getEmpno()+"'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('사원 정보 수정 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}	
		
	}

}
