package com.member.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MemberDAO {

	// 멤버변수
	// 1. DB와 연동하는 객체.
	Connection con = null;
	
	// 2. DB에 SQL문을 전송하는 객체.
	PreparedStatement pstmt = null;
	
	// 3. SQL문을 실행한 후에 결과값을 가지고 있는 객체.
	ResultSet rs = null;
	
	// 4. SQL 문을 저장할 문자열 객체.
	String sql = null;
	
	
	public MemberDAO() { 
		
		String driver = "oracle.jdbc.driver.OracleDriver";
		
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		
		String user = "web";
		
		String password = "2580";
		
		
		
		try {
			// 1단계 : 오라클 드라이버 메모리로 로딩
			Class.forName(driver);
			
			// 2단계 : 오라클 데이터베이스와 연결 작업 시도.
			con = DriverManager.getConnection(url, user, password);
			
			if(con != null) {
				System.out.println("데이터베이스 연결 성공!!!");
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}  // 기본 생성자
	
	
	// member 테이블에서 회원 전체 목록을 조회하는 메서드.
	public List<MemberDTO> getMemberList() {
		
		List<MemberDTO> list = new ArrayList<MemberDTO>();
		
		
		try {
			// 3단계 : 데이터베이스에 전송할 SQL문 작성.
			sql = "select * from member order by memno desc";
			
			// 4단계 : SQL문을 데이터베이스 전송 객체에 저장.
			pstmt = con.prepareStatement(sql);
			
			// 5단계 : 데이터베이스에 SQL문 전송 및 실행.
			rs = pstmt.executeQuery();
			
			// 6단계 : SQL문 실행 결과를 반복하여 DTO객체에 저장 및 list에 추가.
			while(rs.next()) {
				
				MemberDTO dto = new MemberDTO();
				
				dto.setMemno(rs.getInt("memno"));
				dto.setMemid(rs.getString("memid"));
				dto.setMemname(rs.getString("memname"));
				dto.setMempwd(rs.getString("mempwd"));
				dto.setAge(rs.getInt("age"));
				dto.setMileage(rs.getInt("mileage"));
				dto.setJob(rs.getString("job"));
				dto.setAddr(rs.getString("addr"));
				dto.setRegdate(rs.getString("regdate"));
				
				list.add(dto);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {	
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return list;
	}  // getMemberList() 메서드 end
	
	
	// 회원 번호에 해당하는 회원의 정보를 조회하는 메서드.
	public MemberDTO contentMember(int num) {
		
		MemberDTO dto = null;
		
		
		try {
			// 3단계 : 데이터베이스에 전송할 SQL문 작성.
			sql = "select * from member where memno = ?";
			
			// 4단계 : SQL문을 데이터베이스 전송 객체에 저장.
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, num);
			
			// 5단계 : 데이터베이스에 SQL문 전송 및 실행.
			rs = pstmt.executeQuery();
			
			// 6단계 : SQL문 실행 결과를 memberDTO에 저장.
			if(rs.next()) {
				
				dto = new MemberDTO();
				
				dto.setMemno(rs.getInt("memno"));
				dto.setMemid(rs.getString("memid"));
				dto.setMemname(rs.getString("memname"));
				dto.setMempwd(rs.getString("mempwd"));
				dto.setAge(rs.getInt("age"));
				dto.setMileage(rs.getInt("mileage"));
				dto.setJob(rs.getString("job"));
				dto.setAddr(rs.getString("addr"));
				dto.setRegdate(rs.getString("regdate"));
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				// if(con != null) con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return dto;
	}  // contentMember() 메서드 end


	// member 테이블에 회원을 등록하는 메서드.
	public int insertMember(MemberDTO dto) {
		
		int result = 0, count = 0;
		
		try {
			// 3단계 : 데이터베이스에 전송할 SQL문 작성.
			sql = "select max(memno) from member";
			
			// 4단계 : SQL문을 데이터베이스 전송 객체에 저장.
			pstmt = con.prepareStatement(sql);
			
			// 5단계 : 데이터베이스에 SQL문 전송 및 실행.
			rs = pstmt.executeQuery();
			
			// 6단계 : SQL문 실행 결과를 memberDTO에 저장.
			if(rs.next()) {
				
				count = rs.getInt(1);
				
			}
			
			// 3단계 : 데이터베이스에 전송할 SQL문 작성.
			sql = "insert into member values(?, ?, ?, ?, ?, ?, ?, ?, sysdate)";
			
			// 4단계 : SQL문을 데이터베이스 전송 객체에 저장.
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, count + 1);			
			pstmt.setString(2, dto.getMemid());
			pstmt.setString(3, dto.getMemname());
			pstmt.setString(4, dto.getMempwd());
			pstmt.setInt(5, dto.getAge());
			pstmt.setInt(6, dto.getMileage());
			pstmt.setString(7, dto.getJob());
			pstmt.setString(8, dto.getAddr());
			
			// 5단계 : 데이터베이스에 SQL문 전송 및 실행.
			result = pstmt.executeUpdate();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return result;
		
	} // insertMember() 메서드 end


	public int updateMember(MemberDTO dto) {
		
		int res = 0;
		
		try {
			// 3단계 : 데이터베이스에 전송할 SQL문 작성
			sql = "update member set age = ?, "
					+ "mileage = ?, job = ?, "
					+ "addr = ? where memno = ? ";
			
			// 4단계 : SQL문을 데이터베이스 전송 객체에 저장.
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, dto.getAge());
			pstmt.setInt(2, dto.getMileage());
			pstmt.setString(3, dto.getJob());
			pstmt.setString(4, dto.getAddr());
			pstmt.setInt(5, dto.getMemno());
			
			// 5단계 : 데이터베이스에 SQL문 전송 및 실행.
			res = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return res;
		
		
		
	} // updateMember() 메서드 end


	public int deleteMember(int no) {
		
		int result = 0;
		
		try {
			// 3단계 : 데이터베이스에 전송할 SQL문 작성
			sql = "delete from member where memno = ?";
			
			// 4단계 : SQL문을 데이터베이스 전송 객체에 저장.
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, no);
			
			// 5단계 : 데이터베이스에 SQL문 전송 및 실행.
			result = pstmt.executeUpdate();
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				// if(con != null) con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return result;
	}// deleteMember() 메서드 end

    // 회원번호 재작업 해주는 메서드.
	public void updateNum(int no) {
		
		try {
			// 3단계 : 데이터베이스에 전송할 SQL문 작성
			sql = "update member set memno = memno - 1 "
					+ " where memno > ?";
			
			// 4단계 : SQL문을 데이터베이스 전송 객체에 저장.
			pstmt = con.prepareStatement(sql);
			
            pstmt.setInt(1, no);
			
			// 5단계 : 데이터베이스에 SQL문 전송 및 실행.
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		
	}
	
	
	
	
	
	
}
