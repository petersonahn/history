package com.member.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.member.model.MemberDAO;
import com.member.model.MemberDTO;


@WebServlet("/select.go")
public class SelectServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public SelectServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 전체 회원 목록을 보여 달라고 요청.
		// DB에서 member 테이블의 회원 전체 리스트를 조회하여
		// 해당 회원 목록을 view page로 넘겨주는 비지니스 로직.
		
		// 1단계 : 데이터베이스와 연동
		MemberDAO dao = new MemberDAO();
		
		// 2단계 : member 테이블의 회원 전체 리스트를 조회해야 함.
		List<MemberDTO> memberList = dao.getMemberList();
		
		request.setAttribute("Members", memberList);
		
		// 3단계 : 페이지 이동을 진행하자.
		request.getRequestDispatcher("member_list.jsp").
					forward(request, response);
		
	}

}
