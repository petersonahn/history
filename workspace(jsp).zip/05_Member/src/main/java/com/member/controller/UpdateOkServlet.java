package com.member.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.member.model.MemberDAO;
import com.member.model.MemberDTO;


@WebServlet("/modify_ok.go")
public class UpdateOkServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public UpdateOkServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 회원 수정 폼 페이지에서 넘어온 데이터들을 받아서
		// member 테이블에서 회원의 정보를 수정하는 비지니스 로직.
		
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		// 1단계 : 회원 등록 폼 페이지에서 넘어온 데이터들을 받아주어야 한다.
		String member_id = request.getParameter("mem_id").trim();
		String member_name = request.getParameter("mem_name").trim();
		String member_pwd = request.getParameter("mem_pwd").trim();
		String member_age = request.getParameter("mem_age").trim();
		String member_mileage = request.getParameter("mem_mileage").trim();
		String member_job = request.getParameter("mem_job").trim();
		String member_addr = request.getParameter("mem_addr").trim();
		
		// type="hidden"으로 넘어온 데이터들도 받아주어야 한다.
		String member_no = request.getParameter("mem_no").trim();
		String db_pwd = request.getParameter("db_pwd").trim();
		
		MemberDTO dto = new MemberDTO();
		
		dto.setMemno(Integer.parseInt(member_no));
		dto.setMemid(member_id);
		dto.setMemname(member_name);
		dto.setMempwd(member_pwd);
		dto.setAge(Integer.parseInt(member_age));
		dto.setMileage(Integer.parseInt(member_mileage));
		dto.setJob(member_job);
		dto.setAddr(member_addr);
		
		MemberDAO dao = new MemberDAO();
		
		PrintWriter out = response.getWriter();
		
		if(dto.getMempwd().equals(db_pwd)) {
			// 비밀번호가 일치하는 경우
			int check = dao.updateMember(dto);
			
			if(check > 0) {
				// 회원등록이 성공한 경우
				out.println("<script>");
				out.println("alert('회원 정보 수정 성공!!!')");
				out.println("location.href='content.go?num="+dto.getMemno()+"'");
				out.println("</script>");
			} else {
				// 회원등록이 실패한 경우
				out.println("<script>");
				out.println("alert('회원 정보 수정 실패~~~')");
				out.println("history.back()");
				out.println("</script>");
			}
		} else {
			// 비밀번호가 틀린 경우
			out.println("<script>");
			out.println("alert('비밀번호가 틀립니다. 다시 확인해 주세요~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
	}

}
