package com.boot.react.model;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

/*
 * Mapper
   - 마이바티스(Mybais)는 Mapper 인터페이스를 제공함.
   - 관계형 데이터베이스(RDBMS)를 자바의 객체 지향 모델로 
     매핑하게 도와주는 인터페이스임. 해당 프레임워크는 RDBMS에 
     접근할 때 필요한 자바코드를 현저하게 줄일 수 있도록 해 줌. 
     간단한 XML Statements를 사용해서 java beans를 
     SQL statement에 맵핑을 시킴.
   - 또한, MyBatis Data Mapper API는 개발자에게 java beans 
     객체를 PreparedStatment 파라미터와 ResultSets으로 쉽게 
     매핑할 수 있도록 함. 즉, 파라미터(beans, Map 등)로써 
     객체를 제공함. 파라미터 객체는 update 내에 입력 값을 세팅하기 
     위해 사용되거나 쿼리문의 where 절을 세팅하기 위해서 사용됨.
   - Mapping된 statment를 실행하면 Data Mapper 프레임워크는 
     PreparedStatement 인스턴스를 생성할 것이고, 제공된 파라미터 
     객체를 사용해서 파라미터를 세팅함. 그리고 statement를 실행하고 
     ResultSet으로부터 결과 객체를 생성함.
     
* Mapper 사용했을 때의 장점
  - 맵퍼 인터페이스를 개발자가 직접 작성함.
  - 패키지 이름 + "." + 인터페이스 이름 + "." + 메소드 이름의 
    네임스페이스 + "." + SQL의 ID를 설정해야 함.
  - namespace 속성에는 패키지를 포함한 Mapper 인터페이스 이름 형식임.
  - SQL ID 에는 매핑하는 메소드 이름을 지정하는 것임.

* Mapper 인터페이스 작성
  - 반드시 인터페이스로 선언해 주어야 함.
  - namespace 명은 패키지 포함 인터페이스 이름으로 작성함.
    예) <mapper namespace="myspring.user.dao.UserMapper">
  - 메소드명은 SQL ID와 동일하게 작성함.
*/


@Mapper
public interface MemberMapper {

	List<Member> list();
	
	int add(Member dto);
	
	Member cont(int no);
	
	int modify(Member dto);
	
	int del(int no);
	
	void seq(int no);
	
	List<Member> search(Map<String, String> map);
	
}
