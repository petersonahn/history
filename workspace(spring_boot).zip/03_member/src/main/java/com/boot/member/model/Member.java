package com.boot.member.model;

import lombok.Data;

@Data
public class Member {

	private int memno;
	private String memid;
	private String memname;
	private String mempwd;
	private int age;
	private int mileage;
	private String job;
	private String addr;
	private String regdate;
	
}
