package com.json.board.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.json.board.model.Board;


import com.json.board.model.BoardMapper;

@Controller
public class BoardController {
	
	@Autowired
	private BoardMapper mapper;
	    	
	@RequestMapping("/")
    public String main() {
		
		return "main";
		
	}
	
	@RequestMapping("board_list.go")
	@ResponseBody
	public List<Board> list() {
		
		List<Board> list = this.mapper.list();
		
		return list;
		
	}
	
	@RequestMapping("board_write_ok.go")
	@ResponseBody
	public void insert(Board dto) {
		
		this.mapper.add(dto);
		
	}
	
	@RequestMapping("board_edit_ok.go")
	@ResponseBody
	public String editOk(Board dto) {
		Board cont = this.mapper.cont(dto.getBoard_no());
		
		String res = null;
		
		if(cont.getBoard_pwd().equals(dto.getBoard_pwd())) {
			
			int result = this.mapper.edit(dto);
			
			if(result > 0) {
				res = "OK";
			}else {
				res = "FAIL";
			}
			
		}else {
			res = "PASSWORD";
		}
		
		return res;
	}
	
	@PostMapping("board_delete_ok.go")
	@ResponseBody
	public String delete(Board dto) {
		// 1. 글번호로 상세정보를 하나 가져오자.
		Board cont = this.mapper.cont(dto.getBoard_no());
		
		String res = null;
		
		// 2. 비밀번호가 맞는지 확인.
		if(cont.getBoard_pwd().equals(dto.getBoard_pwd())) {
			
			int chk = this.mapper.del(dto.getBoard_no());
			
			if(chk > 0) {
				// 글 번호 재작업 진행.
				this.mapper.seq(dto.getBoard_no());
				
				res = "OK";
				
			}else {
				
				res = "FAIL";
				
			}
		} else {
			// 비밀번호가 틀린 경우
			res = "PASSWORD";
		}
		
		return res;
	}
			
}
