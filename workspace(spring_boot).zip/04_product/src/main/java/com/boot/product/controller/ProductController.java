package com.boot.product.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.boot.product.model.Category;
import com.boot.product.model.Product;
import com.boot.product.model.ProductMapper;

import jakarta.servlet.http.HttpServletResponse;


@Controller
public class ProductController {

	@Autowired
	private ProductMapper mapper;
	
	
	@GetMapping("/")
	public String home() {
		
		return "main";
	}
	
	@GetMapping("product_list.go")
	public String list(Model model) {
		
		List<Product> list = this.mapper.list();
		
		model.addAttribute("List", list);
		
		return "product_list";
	}
	
	@GetMapping("product_insert.go")
	public String insert(Model model) {
		
		List<Category> cList = this.mapper.category();
		
		model.addAttribute("CartList", cList);
		
		return "product_insert";
	}
	
	
	@PostMapping("product_insert_ok.go")
	public void insert_ok(Product dto,
			HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		int result = this.mapper.add(dto);
		
		if(result > 0) {
			out.println("<script>");
			out.println("alert('제품 등록 성공!!!')");
			out.println("location.href='product_list.go'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('제품 등록 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
	
	@GetMapping("product_content.go")
	public String cont(@RequestParam("pnum") int pnum, Model model) {
		
		Product content = this.mapper.cont(pnum);
		
		model.addAttribute("Cont", content);
		
		return "product_content";
	}
	
	
	@GetMapping("product_modify.go")
	public String modify(@RequestParam("pnum") int pnum, Model model) {
		
		Product cont = this.mapper.cont(pnum);
		
		model.addAttribute("Modify", cont);
		
		return "product_modify";
	}
	
	@PostMapping("product_modify_ok.go")
	public void modifyOk(Product dto,
			HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		int check = this.mapper.modify(dto);
		
		if(check > 0) {
			out.println("<script>");
			out.println("alert('제품 수정 성공!!!')");
			out.println("location.href='product_content.go?pnum="+dto.getPnum()+"'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('제품 수정 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
	@GetMapping("product_delete.go")
	public void delete(@RequestParam("pnum") int pnum,
					HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		int chk = this.mapper.del(pnum);
		
		if(chk > 0) {
			
			this.mapper.seq(pnum);
			
			out.println("<script>");
			out.println("alert('제품 삭제 성공!!!')");
			out.println("location.href='product_list.go'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('제품 삭제 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
	}
	
}
