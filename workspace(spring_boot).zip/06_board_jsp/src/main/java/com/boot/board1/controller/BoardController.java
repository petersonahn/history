package com.boot.board1.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.boot.board1.model.Board;
import com.boot.board1.model.Page;

import jakarta.servlet.http.HttpServletResponse;

import com.boot.board1.model.BoardMapper;

@Controller
public class BoardController {
	
	@Autowired
	private BoardMapper mapper;
	
    private final int rowsize = 3;
	
	private int totalRecord = 0;
	
	@GetMapping("/")
    public String main() {
		
		return "main";
		
	}
	
	@GetMapping("board_list.go")
	public String list(@RequestParam(value = "page", defaultValue = "1") int page, 
			Model model) {
		
		totalRecord = this.mapper.count();
		
		Page pdto = new Page(page, rowsize, totalRecord);
		
		List<Board> list = this.mapper.list(pdto);
		
		model.addAttribute("List", list)
		     .addAttribute("Paging", pdto);
		
		return "board_list";
		
	}
	
	@GetMapping("board_write.go")
    public String write() {
		
		return "board_write";
		
	}
	
	@PostMapping("board_write_ok.go")
	public void write_ok(Board bvo,
			HttpServletResponse response) throws IOException {
		
		int result = this.mapper.add(bvo);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(result > 0) {
			
			out.println("<script>");
			out.println("alert('게시글 등록 성공!!!')");
			out.println("location.href='board_list.go'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('게시글 등록 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
				
	}
	
	@GetMapping("board_content.go")
	public String cont(@RequestParam("no") int no,
			Model model) {		

		this.mapper.read(no);
		
		Board cont = this.mapper.cont(no);
		
		
		model.addAttribute("Cont", cont);
		
		
		return "board_content";
	
	}
	
	@GetMapping("board_modify.go")
	public String modify(@RequestParam("no") int no,
			Model model) {

		Board cont = this.mapper.cont(no);
		
		model.addAttribute("Modify", cont);
		
		
		return "board_modify";
	
	}
	
	@PostMapping("board_modify_ok.go")
	public void modify_ok(Board dto, Page pdto,
			@RequestParam("db_pwd") String db_pwd,
			HttpServletResponse response) throws IOException {
			
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(db_pwd.equals(dto.getBoard_pwd())) {
			
			int result = this.mapper.edit(dto);
			
			if(result > 0) {
				out.println("<script>");
				out.println("alert('회원 정보 수정 성공!!!')");
				out.println("location.href='board_content.go?no="+dto.getBoard_no()+"&page="+ pdto.getPage() +"'");
				out.println("</script>");
			}else {
				out.println("<script>");
				out.println("alert('회원 정보 수정 실패~~~')");
				out.println("history.back()");
				out.println("</script>");
			}
		
		}else {
			// 비밀번호가 틀린 경우
			out.println("<script>");
			out.println("alert('비밀번호가 틀립니다. 확인해 주세요~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}	
	
	@GetMapping("board_delete.go")
	public String delete(@RequestParam("no") int no,
			Model model) {

		model.addAttribute("no", no);
		
		return "board_delete";
	
	}
	
	@PostMapping("board_delete_ok.go")
	public void delete_ok(@RequestParam("no") int no,
			@RequestParam("pwd") String pwd,
			HttpServletResponse response) throws IOException {
	
		Board cont = this.mapper.cont(no);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(pwd.equals(cont.getBoard_pwd())) {
			
			int check = this.mapper.del(no);
			
			if(check > 0) {
				// 회원 삭제 후 회원번호 재작업 메서드 호출.
				this.mapper.seq(no);
				
				out.println("<script>");
				out.println("alert('게시글 삭제 성공!!!')");
				out.println("location.href='board_list.go'");
				out.println("</script>");
				
			}else {
				out.println("<script>");
				out.println("alert('게시글 삭제 실패~~~')");
				out.println("history.back()");
				out.println("</script>");
			}
			
		}else {
			// 비밀번호가 틀린 경우
			out.println("<script>");
			out.println("alert('비밀번호가 틀립니다. 확인 부탁~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
	@RequestMapping("board_search.go")
	public String search(@RequestParam("field") String field,
			@RequestParam("keyword") String keyword,
			@RequestParam(value = "page", defaultValue = "1") int page,
			Model model) {
		        		
		Map<String, String> map = 
				new HashMap<String, String>();
		
		map.put("Field", field);
		map.put("Keyword", keyword);
		
		totalRecord = this.mapper.scount(map);
		
		Page pdto = new Page(page, rowsize, totalRecord, field, keyword);
		
		List<Board> searchList = this.mapper.search(pdto);
		
		model.addAttribute("SearchList", searchList)
	         .addAttribute("Paging", pdto);
	
	
	    return "board_search_list";
	}
	
}
