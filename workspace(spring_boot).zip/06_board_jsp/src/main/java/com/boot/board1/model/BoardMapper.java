package com.boot.board1.model;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BoardMapper {
	
	int count();
	
    List<Board> list(Page pvo);
	
	int add(Board bvo);
	
	void read(int no);
	
	Board cont(int no);
	
	int edit(Board bvo);
	
	int del(int no);
	
	void seq(int no);
	
	int scount(Map<String, String> map);
	
	List<Board> search(Page pvo);
	
}
